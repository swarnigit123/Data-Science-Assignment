#!/usr/bin/env python
# coding: utf-8

# ## Assignment on multilinear Regression_Toyota_Corolla_data

# In[1]:


#Import libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import statsmodels.formula.api as smf
import statsmodels.api as sm


# In[2]:


#Load Data
toyota = pd.read_csv('ToyotaCorolla.csv',encoding='latin1')


# In[3]:


toyota.head()


# ### EDA and Data visualization

# In[4]:


toyota.shape


# In[5]:


toyota.describe()


# In[6]:


toyota.info()


# In[7]:


toyota1 = pd.concat([toyota.iloc[:,2:4],toyota.iloc[:,6:7],toyota.iloc[:,8:9],toyota.iloc[:,12:14],toyota.iloc[:,15:18]],axis=1)


# In[8]:


toyota1


# In[9]:


toyota2 = toyota1.rename({'Age_08_04':'Age','cc':'CC'},axis=1)


# In[10]:


toyota2


# In[11]:


#Duplicate values
toyota2[toyota2.duplicated()]


# In[12]:


toyota3 = toyota2.drop_duplicates().reset_index(drop=True)
toyota3


# In[13]:


toyota3.describe()


# ### Correlation Analysis

# In[15]:


toyota3.corr()


# In[67]:


#pairplot
sns.set_style(style='darkgrid')
sns.pairplot(toyota3)


# ### Model building

# In[17]:


model = smf.ols('Price~Age+KM+HP+CC+Doors+Gears+Quarterly_Tax+Weight', data=toyota3).fit()


# ### Model testing

# In[68]:


model.params


# In[19]:


#Checking tvalues and pvalues
model.tvalues, np.round(model.pvalues, 5)


# In[20]:


model.summary()


# In[21]:


#Build SLR and MLR models for insignificant variables


# In[22]:


model_c = smf.ols('Price~CC',data=toyota3).fit()
model_c.tvalues,model_c.pvalues


# In[23]:


model_d = smf.ols('Price~Doors', data=toyota3).fit()
model_d.tvalues,model_d.pvalues


# In[24]:


model_cd = smf.ols('Price~CC+Doors', data=toyota3).fit()
model_cd.tvalues,model_cd.pvalues


# ### Model Validation Techniques

# In[25]:


#Calculating VIF
#Checking Collinearity problem


# In[26]:


rsq_age=smf.ols('Age~KM+HP+CC+Doors+Gears+Quarterly_Tax+Weight',data=toyota3).fit().rsquared
vif_age=1/(1-rsq_age)

rsq_KM=smf.ols('KM~Age+HP+CC+Doors+Gears+Quarterly_Tax+Weight',data=toyota3).fit().rsquared
vif_KM=1/(1-rsq_KM)

rsq_HP=smf.ols('HP~Age+KM+CC+Doors+Gears+Quarterly_Tax+Weight',data=toyota3).fit().rsquared
vif_HP=1/(1-rsq_HP)

rsq_CC=smf.ols('CC~Age+KM+HP+Doors+Gears+Quarterly_Tax+Weight',data=toyota3).fit().rsquared
vif_CC=1/(1-rsq_CC)

rsq_DR=smf.ols('Doors~Age+KM+HP+CC+Gears+Quarterly_Tax+Weight',data=toyota3).fit().rsquared
vif_DR=1/(1-rsq_DR)

rsq_GR=smf.ols('Gears~Age+KM+HP+CC+Doors+Quarterly_Tax+Weight',data=toyota3).fit().rsquared
vif_GR=1/(1-rsq_GR)

rsq_Quarterly_Tax=smf.ols('Quarterly_Tax~Age+KM+HP+CC+Doors+Gears+Weight',data=toyota3).fit().rsquared
vif_Quarterly_Tax=1/(1-rsq_Quarterly_Tax)

rsq_WT=smf.ols('Weight~Age+KM+HP+CC+Doors+Gears+Quarterly_Tax',data=toyota3).fit().rsquared
vif_WT=1/(1-rsq_WT)


# In[27]:


#Dataframe format
d1={'Variables':['Age','KM','HP','CC','Doors','Gears','Quarterly_Tax','Weight'],
    'Vif':[vif_age,vif_KM,vif_HP,vif_CC,vif_DR,vif_GR,vif_Quarterly_Tax,vif_WT]}
Vif_df=pd.DataFrame(d1)
Vif_df


# In[28]:


#All variables have VIF less than 20 therefore no multicollinerity in variables
#so we will consider all the variables in model building


# In[29]:


#Residual Analysis
#Test for Normality of Residuals (Q-Q plot)


# In[30]:


sm.qqplot(model.resid,line='q')        # 'q' - A line is fit through the quartiles 
plt.title("Normal Q-Q plot of residuals")
plt.show()


# In[31]:


list(np.where(model.resid>6000))


# In[32]:


list(np.where(model.resid<-6000))


# In[69]:


#Residual plot for Homoscedasticity


# In[34]:


def standard_values(vals):
    return (vals-vals.mean())/vals.std()


# In[35]:


plt.scatter(standard_values(model.fittedvalues),standard_values(model.resid))
plt.title('Residual Plot')
plt.xlabel('standardized fitted values')
plt.ylabel('standardized residual values')
plt.show()


# In[36]:


#Test for errors
#using residual regression plot code
#graphics.plot_regress_exog(model,'x',fig)
#exog = x variable and endog = y variable


# In[37]:


fig = plt.figure(figsize=(20,10))
sm.graphics.plot_regress_exog(model,"Age",fig=fig)
plt.show()


# In[38]:


fig = plt.figure(figsize=(20,10))
sm.graphics.plot_regress_exog(model,"KM",fig=fig)
plt.show()


# In[39]:


fig = plt.figure(figsize=(20,10))
sm.graphics.plot_regress_exog(model,"HP",fig=fig)
plt.show()


# In[40]:


fig = plt.figure(figsize=(20,10))
sm.graphics.plot_regress_exog(model,"CC",fig=fig)
plt.show()


# In[41]:


fig = plt.figure(figsize=(20,10))
sm.graphics.plot_regress_exog(model,"Doors",fig=fig)
plt.show()


# In[42]:


fig = plt.figure(figsize=(20,10))
sm.graphics.plot_regress_exog(model,"Gears",fig=fig)
plt.show()


# In[43]:


fig = plt.figure(figsize=(20,10))
sm.graphics.plot_regress_exog(model,"Quarterly_Tax",fig=fig)
plt.show()


# ### Model Deletion Techniques

# In[44]:


#Detecting outliers/influencers
#Cook's distance


# In[45]:


#Get influencers using cooks distance
model.influence = model.get_influence()
(c, _) = model.get_influence().cooks_distance


# In[46]:


c


# In[47]:


#plot cooks distance plot
fig=plt.figure(figsize=(20,10))
plt.stem(np.arange(len(toyota3)),np.round(c,3))
plt.xlabel('Row Index')
plt.ylabel('Cooks Distance')
plt.show()


# In[48]:


np.argmax(c), np.max(c)


# In[49]:


#Influence plot
from statsmodels.graphics.regressionplots import influence_plot
fig,ax = plt.subplots(figsize=(20,20))
fig = influence_plot(model,ax = ax)


# In[50]:


#Leverage Cutoff

k = toyota3.shape[1]
n = toyota3.shape[0]
leverage_cutoff = 3*(k+1)/n


# In[51]:


leverage_cutoff


# In[52]:


toyota3[toyota3.index.isin([80])]


# ### Improving model

# In[54]:


toyota_new = toyota3.copy()
toyota_new


# In[55]:


#droping data points which are outliers and reset index
toyota4 = toyota_new.drop(toyota_new.index[[80]],axis=0).reset_index(drop=True)
toyota4


# ### Build model

# In[57]:


final_model = smf.ols('Price~Age+KM+HP+CC+Doors+Gears+Quarterly_Tax+Weight',data=toyota4).fit()


# In[59]:


final_model.summary()


# In[60]:


final_model.rsquared


# In[61]:


#Rsquared value is improved


# ### Model Prediction

# In[62]:


new_data = pd.DataFrame({'Age':[15,17,18],'KM':[50000,55000,60000],'HP':[70,75,75],'CC':[1400,1500,1500],'Doors':[3,5,5],'Gears':[6,6,6],'Quarterly_Tax':[75,75,75],'Weight':[1020,1020,1020]})


# In[63]:


new_data


# In[64]:


final_model.predict(new_data)


# In[65]:


pred_y = final_model.predict(toyota4)
pred_y


# In[ ]:




