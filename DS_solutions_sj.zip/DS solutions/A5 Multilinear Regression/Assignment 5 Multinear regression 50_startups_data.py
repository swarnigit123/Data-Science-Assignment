#!/usr/bin/env python
# coding: utf-8

# ## Prediction model for profit of 50_startups data.

# In[1]:


#Import libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns


# In[2]:


#Load Data
startups = pd.read_csv('50_startups.csv')


# In[3]:


startups.head(10)


# ### EDA

# In[4]:


startups.shape


# In[5]:


startups.info()


# In[6]:


startups.describe()


# In[7]:


startups1=startups.rename({'R&D Spend':'RD_spend','Marketing Spend':'Marketing_spend'},axis=1)
startups1


# In[8]:


startups1.isna().sum()


# ### correlation analysis

# In[9]:


#Checking collinearity between i/p variables
startups1.corr()


# In[10]:


sns.set_style(style='darkgrid')
sns.pairplot(startups1)


# ### Building model

# In[11]:


import statsmodels.formula.api as smf
model = smf.ols('Profit~RD_spend+Administration+Marketing_spend', data = startups1).fit()


# ### Model testing

# In[12]:


model.params


# In[13]:


#Checking T-values and p-values
np.round(model.tvalues, 4), np.round(model.pvalues, 4)


# In[14]:


model.summary()


# In[15]:


#Build SLR and MLR models for insignificant variables


# In[16]:


model_M = smf.ols('Profit~ Marketing_spend', data= startups1).fit()


# In[17]:


model_M.summary()


# In[18]:


model_A = smf.ols('Profit~ Administration', data= startups1).fit()


# In[19]:


model_A.summary()


# In[20]:


model_AM = smf.ols('Profit~ Administration+Marketing_spend', data= startups1).fit()


# In[21]:


model_AM.summary()


# ### Model Validation Techniques

# In[22]:


#1) Collinearity Problem Check
# Calculate VIF = 1/(1-Rsquare) for all independent variables

rsq_r = smf.ols('RD_spend~ Administration+Marketing_spend', data=startups1).fit().rsquared
vif_r = 1/(1-rsq_r)

rsq_a = smf.ols('Administration ~ RD_spend+Marketing_spend', data=startups1).fit().rsquared
vif_a = 1/(1-rsq_a)

rsq_m = smf.ols('Marketing_spend~ RD_spend+Administration', data=startups1).fit().rsquared
vif_m = 1/(1-rsq_m)

d1 = {'Varriables':['RD_spend','Administration','Marketing_spend'], 'Vif':[vif_r,vif_a,vif_m]}
vif_df= pd.DataFrame(d1)
vif_df


# In[23]:


#All variables have VIF less than 20 therefore no multicollinerity in variables
#so we will consider all the variables in model building


# In[24]:


#2)Residual Analysis
#Test for Normality of Residuals Q-Q plot


# In[25]:


import statsmodels.api as sm
sm.qqplot(model.resid,line='q') # line = 45 to draw the diagnoal line
plt.title("Normal Q-Q plot of residuals")
plt.show()


# In[26]:


list(np.where(model.resid>10))


# In[27]:


list(np.where(model.resid<-.10))


# In[28]:


#Test for Homoscedasticity

def get_standardized_values(vals):
    return (vals - vals.mean())/vals.std()


# In[29]:


#Residual plot for  Homoscedasticity
plt.scatter(get_standardized_values(model.fittedvalues),
            get_standardized_values(model.resid))

plt.title('Residual Plot')
plt.xlabel('standarized fitted values')
plt.ylabel('standarized residual values')
plt.show()


# In[30]:


#Test for errors
#using residual regression plot code
#graphics.plot_regress_exog(model,'x',fig)
#exog = x variable and endog = y variable


# In[31]:


fig = plt.figure(figsize=(20,10))
sm.graphics.plot_regress_exog(model,'RD_spend', fig=fig)
plt.show


# In[32]:


fig = plt.figure(figsize=(20,10))
sm.graphics.plot_regress_exog(model,'Administration', fig=fig)
plt.show


# In[33]:


fig = plt.figure(figsize=(20,10))
sm.graphics.plot_regress_exog(model,'Marketing_spend', fig=fig)
plt.show


# In[34]:


#Detecting Outliers/influencers
#cook's distance


# In[35]:


model.influence = model.get_influence()
(c, _) = model.get_influence().cooks_distance


# In[36]:


c


# In[37]:


#PLot cook's distance plot
fig = plt.subplots(figsize=(20,10))
plt.stem(np.arange(len(startups1)),np.round(c, 3))
plt.xlabel('Row index')
plt.ylabel('Cooks Distance')
plt.show()


# In[38]:


np.argmax(c), np.max(c)


# In[39]:


#Influrnce plot

from statsmodels.graphics.regressionplots import influence_plot
fig,ax = plt.subplots(figsize=(20,15))
influence_plot(model, ax=ax)
plt.show()


# In[40]:


k = startups1.shape[1]
n = startups1.shape[0]
leverage_cutoff = 3*((k+1)/n)


# In[41]:


leverage_cutoff


# In[42]:


startups1[startups1.index.isin([49])]


# In[43]:


startups1.tail()


# ### Improving the model

# In[44]:


#singnificant difference in 49th record so it's outlier and drop it
startups1_new = startups1
startups1_new = startups1_new.drop(startups1_new.index[[49]],axis=0)
startups1_new.tail()


# In[45]:


startups1_new


# ### Rebuilding model

# In[46]:


model1 = smf.ols('Profit~RD_spend+Administration+Marketing_spend', data = startups1_new).fit()


# In[47]:


model1.summary()


# In[48]:


(c1, _)= model1.get_influence().cooks_distance
c1


# In[49]:


fig = plt.subplots(figsize=(20, 10))
plt.stem(np.arange(len(startups1_new)), np.round(c1,3))
plt.xlabel('Row index')
plt.ylabel('Cooks distance')
plt.show()


# In[50]:


np.argmax(c1), np.max(c1)


# In[51]:


#leverage cutoff value
leverage_cutoff = 3*((4 + 1)/49)
leverage_cutoff


# In[52]:


#droping 48th record coz it's outliers
startups1_new[startups1_new.index.isin([48])]


# In[53]:


startups1_new = startups1_new.drop(startups1_new.index[[48]],axis=0)


# In[54]:


startups1_new.tail()


# In[55]:


#Again Rebuilding model

model2 = smf.ols('Profit~RD_spend+Administration+Marketing_spend', data = startups1_new).fit()


# In[56]:


model2.summary()


# In[57]:


(c2, _)= model2.get_influence().cooks_distance
c2


# In[58]:


ig = plt.subplots(figsize=(20, 10))
plt.stem(np.arange(len(startups1_new)), np.round(c2,3))
plt.xlabel('Row index')
plt.ylabel('Cooks distance')
plt.show()


# In[59]:


np.argmax(c2), np.max(c2)


# In[60]:


leverage_cutoff = 3*((4 + 1)/48)
leverage_cutoff


# In[61]:


df2 ={'Model Name':['Model','Model1','Model2'],'Rsquared values': [model.rsquared,model1.rsquared,model2.rsquared]}


# In[62]:


table=pd.DataFrame(df2)
table


# In[63]:


#From table model2 has highest Rsquared value
#we use model2 for prediction


# ### Model Prediction

# In[64]:


pred_data= pd.DataFrame({'RD_spend':[175000,180000,190000],'Administration':[110000,125000,115000],'Marketing_spend':[220000,280000,250000]})


# In[65]:


pred_data


# In[66]:


model2.predict(pred_data)


# In[ ]:




