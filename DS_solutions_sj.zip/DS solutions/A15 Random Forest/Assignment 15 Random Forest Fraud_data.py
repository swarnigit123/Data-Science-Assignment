#!/usr/bin/env python
# coding: utf-8

# ## Random Forest Fraud_data

# In[2]:


#import libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split


# In[3]:


#import dataset
data = pd.read_csv('Fraud_check.csv')


# In[4]:


data


# ### EDA and Visualization

# In[5]:


data.shape


# In[6]:


data.describe()


# In[7]:


data.info()


# In[8]:


data.columns


# In[11]:


data.isnull().sum()


# In[12]:


data['Taxable.Income'].unique()


# In[13]:


len(data['Taxable.Income'].unique())


# In[14]:


data['Taxable.Income'].values


# In[16]:


#Converting the sales column which is continous into categorical
category = pd.cut(data['Taxable.Income'],bins=[0,30000,99619],labels = ['Risky', 'Good'])
data.insert(0, 'Taxable_Group',category)


# In[17]:


data


# In[18]:


from sklearn.preprocessing import LabelEncoder


# In[19]:


encoder =LabelEncoder()
data['Undergrad']=encoder.fit_transform(data['Undergrad'])
data['Marital.Status']=encoder.fit_transform(data['Marital.Status'])
data['Urban']=encoder.fit_transform(data['Urban'])


# In[20]:


data['Taxable_Group'] = encoder.fit_transform(data['Taxable_Group'])


# In[21]:


data


# In[28]:


plt.hist(data)


# In[25]:


data.hist(figsize=(20,20))


# In[29]:


data.boxplot(figsize=(20,20))


# In[30]:


(data['Taxable_Group'].unique())


# In[31]:


data['Taxable_Group'].value_counts()


# In[32]:


data['Taxable_Group'].values


# In[33]:


from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report


# In[34]:


data1 = data[['Undergrad','Marital.Status','City.Population','Work.Experience','Urban']]


# In[35]:


X = data1
y = data['Taxable_Group']


# In[36]:


X


# In[37]:


y


# In[41]:


y_test.value_counts(),y_train.value_counts()


# In[39]:


X_train,X_test,y_train,y_test =train_test_split(X,y,test_size =0.3,random_state =10)


# In[42]:


model = RandomForestClassifier(n_estimators=100,max_depth=3, criterion = 'gini', random_state=10)
model.fit(X_train,y_train)
y_pred = model.predict(X_test)


# In[43]:


print(y_pred)


# In[44]:


accuracy = accuracy_score(y_test,y_pred)
print(accuracy)


# In[45]:


pd.crosstab(y_pred,y_test)


# In[46]:


count_misclassified =(y_test != y_pred).sum()
count_misclassified


# In[47]:


print(classification_report(y_test,y_pred))


# In[50]:


from sklearn.model_selection import KFold
from sklearn.model_selection import cross_val_score


# In[51]:


kfold = KFold(n_splits=10, shuffle = True, random_state=None)
model1 = RandomForestClassifier(n_estimators=100,max_features = 3)
results = cross_val_score(model1,X,y, cv=kfold)


# In[52]:


print(results)


# In[53]:


print(np.mean(results))


# In[54]:


from sklearn.ensemble import BaggingClassifier


# In[55]:


kfold1 = KFold(n_splits =10,shuffle = True, random_state = 10)
model2 = RandomForestClassifier(n_estimators=100,criterion='entropy',max_features =3)
model3 = BaggingClassifier(base_estimator = model2,n_estimators =100,random_state=10)


# In[57]:


results1 = cross_val_score(model3,X,y, cv=kfold1)


# In[58]:


print(results1)


# In[59]:


print(np.mean(results1))


# In[60]:


from sklearn.ensemble import AdaBoostClassifier


# In[61]:


kfold2 = KFold(n_splits=10, random_state=10,shuffle=True)
model = AdaBoostClassifier(n_estimators=100, random_state=10)
results2 = cross_val_score(model, X, y, cv=kfold2)
print(results2.mean())


# In[ ]:




