#!/usr/bin/env python
# coding: utf-8

# ## Random forest company data

# In[34]:


#import libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split


# In[2]:


df = pd.read_csv('Company_Data.csv')
df


# ### EDA and Visualization

# In[3]:


df.shape


# In[4]:


df.describe()


# In[5]:


df.info()


# In[6]:


df.columns


# In[7]:


df.dtypes


# In[8]:


df.isnull().sum()


# In[9]:


#convrting target variable Sales into Categorical variable


# In[10]:


len(df.Sales.unique())


# In[11]:


df.Sales.values


# In[12]:


df['Sales'] = pd.cut(x=df['Sales'],bins=[0,6,12,17], labels=['Low', 'Medium', 'High'], right=False)
df['Sales']


# In[13]:


from sklearn.preprocessing import LabelEncoder
from sklearn import tree
from sklearn.tree import DecisionTreeClassifier


# In[14]:


encoder1 = LabelEncoder()
df['ShelveLoc'] = encoder1.fit_transform(df['ShelveLoc'])
df['Urban'] = encoder1.fit_transform(df['Urban'])
df['US'] = encoder1.fit_transform(df['US'])


# In[15]:


sns.countplot(df['Sales'])


# In[17]:


plt.scatter(x = 'Price', y='Sales', data=df)


# In[19]:


#Checking correlation with the data
df.corr()


# In[28]:


df.hist(figsize=(20,20))


# In[29]:


df.boxplot(figsize=(20,20))


# In[30]:


#Splitting data into train and test


# In[35]:


X = df.iloc[:,1:]
y = df['Sales']


# In[38]:


X_train,X_test,y_train,y_test = train_test_split(X,y, test_size=0.3,random_state = 10)


# In[39]:


y_test


# In[40]:


from sklearn.model_selection import cross_val_score


# In[41]:


model = RandomForestClassifier(n_estimators=100,max_features=3)
model.fit(X_train, y_train)


# In[42]:


y_pred = model.predict(X_test)


# In[44]:


y_pred


# In[46]:


pd.crosstab(y_test,y_pred)


# In[47]:


#Accuracy
np.mean(y_pred==y_test)


# In[48]:


count_misclassified =(y_test != y_pred).sum()
count_misclassified


# In[50]:


from sklearn.metrics import accuracy_score,classification_report
print(classification_report(y_test,y_pred))


# ### Improving the Model

# - When we use the model_selection = train_test_split we got the accuracy as 66% and we try with KFold model_selection

# In[51]:


from sklearn.model_selection import KFold


# In[52]:


kfold = KFold(n_splits=10, shuffle = True, random_state=None)
model1 = RandomForestClassifier(n_estimators=100,max_features = 3)
results = cross_val_score(model1,X,y, cv=kfold)


# In[53]:


print(results)


# In[54]:


print(np.mean(results))


# - The average accuracy of cross_val_score is 0.72% when we use the KFOLD model_selection

# In[55]:


from sklearn.ensemble import BaggingClassifier


# In[56]:


kfold1 = KFold(n_splits =10,shuffle = True, random_state = 10)
model2 = RandomForestClassifier(n_estimators=100,criterion='entropy',max_features =3)
model3 = BaggingClassifier(base_estimator = model2,n_estimators =100,random_state=10)


# In[57]:


results1 = cross_val_score(model3,X,y, cv=kfold1)


# In[58]:


print(results1)


# In[59]:


print(np.mean(results1))


# In[60]:


from sklearn.ensemble import AdaBoostClassifier


# In[63]:


kfold2 = KFold(n_splits=10, random_state=10,shuffle=True)
model = AdaBoostClassifier(n_estimators=100, random_state=10)
results2 = cross_val_score(model, X, y, cv=kfold2)
print(results2.mean())


# - we get the average accuracy 80% by using ensemble technique AdaBoostClassifier

# In[ ]:




