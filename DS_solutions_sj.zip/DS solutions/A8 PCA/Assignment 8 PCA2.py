#!/usr/bin/env python
# coding: utf-8

# ### clustering on wine data

# ### Heirarchical clustering

# In[1]:


#import libraries
import pandas as pd
import numpy as np
import scipy.cluster.hierarchy as sch
from sklearn.cluster import AgglomerativeClustering
import matplotlib.pyplot as plt
import seaborn as sns


# In[2]:


wine_data = pd.read_csv('wine.csv')


# In[3]:


wine_data.head()


# In[4]:


wine_data.describe


# In[5]:


#Normalization function


# In[6]:


def norm_func(i):
    x = (i-i.min())/(i.max()-i.min())
    return (x)


# In[7]:


#Considering only numerical part normalized the dataframe
df_norm = norm_func(wine_data.iloc[:,1:])


# In[8]:


#plot Dendrogram
plt.figure(figsize=(15,7))
dendrogram = sch.dendrogram(sch.linkage(df_norm, method = 'complete'))


# In[9]:


#Create clusters
hc = AgglomerativeClustering(n_clusters=4, affinity = 'euclidean', linkage = 'single')


# In[10]:


y_hc = hc.fit_predict(df_norm)


# In[11]:


clusters = pd.DataFrame(y_hc, columns = ['Clusters'])
clusters


# In[12]:


#Assign clusters to the dataset
wine_data['hclusterid'] = hc.labels_
wine_data


# In[ ]:





# In[ ]:





# ## K-means hierarchical clustering 

# In[13]:


from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler


# In[14]:


#Normalization func
scaler = StandardScaler()
scaled_wine_df = scaler.fit_transform(wine_data.iloc[:,:])


# In[15]:


#How to find optimum number of clusters
#The K-Means algorithm aims to choose centroids that minimise the inertia


# In[16]:


#Elbow curve
wcss = []
for i in range(1,11):
    kmeans = KMeans(n_clusters=i, random_state=0)
    kmeans.fit(scaled_wine_df)
    wcss.append(kmeans.inertia_)
    
plt.plot(range(1,11), wcss)
plt.title('Elbow method')
plt.xlabel('Number of clusters')
plt.ylabel('WCSS')
plt.show()


# In[17]:


#Build Cluster algorithm
clusters_new = KMeans(4, random_state=1150)
clusters_new.fit(scaled_wine_df)


# In[18]:


clusters_new.labels_


# In[19]:


#Assgning clusters to dataset
wine_data['kclusterid'] = clusters_new.labels_
wine_data


# In[20]:


clusters_new.cluster_centers_


# In[21]:


wine_data.groupby('kclusterid').agg(['mean']).reset_index()


# ### DBSCAN

# In[22]:


wine_data.head()


# In[23]:


wine_data.info()


# In[24]:


array = wine_data.values
array


# In[25]:


from sklearn.cluster import DBSCAN
from sklearn.preprocessing import StandardScaler


# In[26]:


#Normalizing data
stscaler = StandardScaler().fit(array)


# In[27]:


X = stscaler.transform(array)


# In[28]:


X


# In[29]:


#Build model
dbscan = DBSCAN(eps=0.8,min_samples=15)
dbscan.fit(X)


# In[30]:


dbscan.labels_


# In[31]:


dbclusterid = pd.DataFrame(dbscan.labels_,columns=['dbcluster'])


# In[32]:


dbclusterid


# In[33]:


pd.concat([wine_data,dbclusterid],axis=1)


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:




