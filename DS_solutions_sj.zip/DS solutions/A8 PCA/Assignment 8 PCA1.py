#!/usr/bin/env python
# coding: utf-8

# In[1]:


#import libraries
import pandas as pd
import numpy as np
from sklearn.decomposition import PCA
from sklearn.preprocessing import scale
import matplotlib.pyplot as plt


# In[2]:


wine = pd.read_csv('wine.csv')


# In[3]:


wine.head()


# In[50]:


wine.shape


# In[4]:


wine.info()


# In[5]:


wine.describe()


# In[6]:


wine.data = wine.iloc[:,1:]
wine.data.head()


# In[7]:


Wine = wine.data.values
Wine


# In[8]:


#Normalizing numerical data
wine_normal = scale(Wine)


# In[9]:


wine_normal


# In[10]:


pca = PCA()
pca_values = pca.fit_transform(wine_normal)


# In[11]:


pca_values


# In[12]:


pca = PCA(n_components = 13)
pca_values = pca.fit_transform(wine_normal)


# In[13]:


#The amount of variance that each PCA explains
var = pca.explained_variance_ratio_
var


# In[14]:


#Cumulative variance
var1 = np.cumsum(np.round(var,decimals = 4)*100)
var1


# In[15]:


pca.components_


# In[16]:


#Variance plot
plt.plot(var1, color = 'blue')


# In[17]:


pca_values[:,0:1]


# In[30]:


#plot between pca1 and pca2
plt.figure(figsize=(10,7))
x = pca_values[:,0:1]
y = pca_values[:,1:2]
plt.scatter(x,y)


# In[24]:


finaldf = pd.concat([pd.DataFrame(pca_values[:,0:3],columns=['pca1','pca2', 'pca3']),wine[['Type']]], axis =1)
finaldf


# In[29]:


plt.figure(figsize=(10,7))
sns.scatterplot(data = finaldf, x= 'pca1', y='pca2', hue= 'Type')


# In[28]:


plt.figure(figsize=(15,8))
sns.scatterplot(data = finaldf)


# ### Hierarchical clustering

# In[31]:


import scipy.cluster.hierarchy as sch
from sklearn.cluster import AgglomerativeClustering


# In[33]:


# Normalization function 
def norm_func(i):
    x = (i-i.min())/(i.max()-i.min())
    return (x)


# In[34]:


finaldf_norm = norm_func(finaldf)


# In[38]:


#create dendrogram
plt.figure(figsize=(15,7))
dendrogram = sch.dendrogram(sch.linkage(finaldf_norm, method='complete'))


# In[39]:


#create clusters
hc = AgglomerativeClustering(n_clusters = 3, affinity = 'euclidean', linkage = 'single')


# In[40]:


y_hc = hc.fit_predict(finaldf_norm)


# In[55]:


hc.labels_


# In[56]:


clusters = pd.DataFrame(y_hc,columns=['clusters'])


# In[57]:


clusters


# In[61]:


#assign clusters to the dataset
wine['hclusterid'] = hc.labels_
wine


# ### K-Means clustering

# In[42]:


from sklearn.cluster import KMeans


# In[43]:


#Normalizing function
from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()


# In[45]:


finaldf_scaled = scaler.fit_transform(finaldf)
finaldf_scaled


# In[46]:


wcss = []
for i in range(1, 11):
    kmeans = KMeans(n_clusters=i,random_state=0)
    kmeans.fit(finaldf_scaled)
    wcss.append(kmeans.inertia_)
    
plt.plot(range(1, 11), wcss)
plt.title('Elbow Method')
plt.xlabel('Number of clusters')
plt.ylabel('WCSS')
plt.show()


# In[47]:


#Build Cluster algorithm
clusters_new = KMeans(4, random_state=1150)
clusters_new.fit(finaldf_scaled)


# In[48]:


clusters_new.labels_


# In[60]:


#assign clusters to the dataset
wine['kclusterid'] = clusters_new.labels_
wine


# ### DBSCAN clustering

# In[65]:


from sklearn.cluster import DBSCAN
from sklearn.preprocessing import StandardScaler


# In[62]:


finaldf.head()


# In[63]:


finaldf.info()


# In[64]:


array = finaldf.values
array


# In[67]:


#Normalizing
stscalar = StandardScaler().fit(array)
X = stscalar.transform(array)
X


# In[74]:


dbscan = DBSCAN(eps=0.8, min_samples = 5)
dbscan.fit(X)


# In[75]:


dbscan.labels_


# In[77]:


cl = pd.DataFrame(dbscan.labels_,columns=['cluster'])
cl


# In[78]:


#assign clusters to the dataset
wine['dbclusterid'] = dbscan.labels_


# In[79]:


wine


# In[ ]:




