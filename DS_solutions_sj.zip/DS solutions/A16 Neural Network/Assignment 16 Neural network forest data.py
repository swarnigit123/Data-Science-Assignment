#!/usr/bin/env python
# coding: utf-8

# In[1]:


#import libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler, LabelEncoder, MinMaxScaler, scale
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import GridSearchCV, KFold, StratifiedKFold, cross_val_score, train_test_split, RandomizedSearchCV
from tensorflow import keras
from keras.optimizers import Adam
from kerastuner.tuners import RandomSearch
from tensorflow.keras import layers
from keras.models import Sequential
from keras.layers import Dense
from keras.layers import Dropout
from keras.utils import np_utils
from keras.constraints import maxnorm
from keras.wrappers.scikit_learn import KerasRegressor, KerasClassifier
from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import mutual_info_regression


# In[2]:


#import datasets
data = pd.read_csv('forestfires.csv')
data


# In[3]:


data.shape


# In[4]:


data.info()


# In[6]:


data.describe()


# In[7]:


data.T


# In[8]:


data.isnull().sum()


# In[10]:


num_feature = data.describe(include=["int","float"]).columns
print(list(num_feature))


# In[13]:


import seaborn as sns
sns.set_style('whitegrid')
sns.pairplot(data[num_feature])
plt.show()


# In[14]:


categorical_features =data.describe(include=["object"]).columns

print(list(categorical_features))


# In[15]:


data1 = data.iloc[:,2:30]


# In[16]:


from sklearn.preprocessing import StandardScaler
sc = StandardScaler()


# In[18]:


sc.fit(data1)
data_norm = sc.transform(data1)
data_norm


# In[19]:


from sklearn.decomposition import PCA
pca = PCA(n_components=28)
pca_values =pca.fit_transform(data_norm)
pca_values


# In[21]:


var = pca.explained_variance_ratio_
var


# In[22]:


var1 = np.cumsum(np.round(var,decimals=4)*100)
var1


# In[37]:


plt.figure(figsize=(12,4))
plt.plot(var1,color="red",marker="P");


# In[25]:


finalDf = pd.concat([pd.DataFrame(pca_values[:,0:22],columns=['pc1','pc2','pc3','pc4','pc5','pc6','pc7',
 'pc8','pc9','pc10','pc11','pc12','pc13','pc14',
 'pc15','pc16','pc17','pc18','pc19','pc20','pc21',
 'pc22']),
data[['size_category']]], axis = 1)
finalDf.size_category.replace(('large','small'),(1,0),inplace=True)
finalDf


# In[26]:


array = finalDf.values
X = array[:,0:22]
Y = array[:,22]


# In[27]:


model = Sequential()
model.add(Dense(12, input_dim=22, activation='relu'))
model.add(Dense(8, activation='relu'))
model.add(Dense(1, activation = 'sigmoid'))


# In[29]:


model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])
# Fit the model
model.fit(X, Y, validation_split=0.3, epochs=150, batch_size=10)                                                                    


# In[30]:


scores =model.evaluate(X,Y)
print("%s: %.2f%%" % (model.metrics_names[1], scores[1]*100))


# ### Changing X and Y to improve Accuracy

# In[32]:


finalDf1 = pd.concat([pd.DataFrame(pca_values[:,0:25],columns=['pc1','pc2','pc3','pc4','pc5','pc6','pc7',
 'pc8','pc9','pc10','pc11','pc12','pc13','pc14',
 'pc15','pc16','pc17','pc18','pc19','pc20','pc21',
 'pc22','pc23','pc24','pc25']),
 data[['size_category']]], axis = 1)
finalDf1.size_category.replace(('large','small'),(1,0),inplace=True)
finalDf1


# In[33]:


array1 = finalDf1.values
x = array1[:,0:25]
y = array1[:,25]


# In[34]:


model1 = Sequential()
model1.add(Dense(12, input_dim=25, activation='relu'))
model1.add(Dense(8,activation='relu'))
model1.add(Dense(1,activation='sigmoid'))


# In[35]:


model1.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])
# Fit the model
model1.fit(x, y, validation_split=0.3, epochs=150, batch_size=10)


# In[36]:


scores = model1.evaluate(x, y)
print("%s: %.2f%%" % (model.metrics_names[1], scores[1]*100))


# In[ ]:




