#!/usr/bin/env python
# coding: utf-8

# ### Classification Model using Naive Bayes method on salary data

# In[2]:


#import libraries
import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.naive_bayes import MultinomialNB as MB
from sklearn.naive_bayes import GaussianNB as GB


# In[3]:


#import datasets
salarytrain = pd.read_csv('SalaryData_Train.csv')
salarytest = pd.read_csv('SalaryData_Test.csv')


# In[4]:


#copy datasets
salarytest1 = salarytest.copy()
salarytrain1 = salarytrain.copy()


# In[5]:


salarytrain1.head()


# In[6]:


salarytest1.head()


# ### EDA and Data preprocessing

# In[7]:


salarytrain1.dtypes


# In[8]:


salarytest1.dtypes


# In[9]:


salarytrain1.info()


# In[10]:


salarytest1.info()


# In[11]:


salarytrain1.isnull().sum()


# In[12]:


salarytest1.isnull().sum()


# In[13]:


sns.countplot(salarytest1["Salary"])


# In[15]:


#Converting non-numeric data into numeric
train_data = salarytrain1.iloc[:,0:13]
train_data = pd.get_dummies(train_data)
train_data


# In[16]:


test_data = salarytest1.iloc[:,0:13]
test_data = pd.get_dummies(test_data)
test_data


# In[17]:


finaltrain = pd.concat([train_data, salarytrain1['Salary']],axis=1)
finaltrain


# In[18]:


finaltest = pd.concat([test_data, salarytest1['Salary']],axis=1)
finaltest


# In[19]:


#Divid finaltrain and finaltest data
X = finaltrain.values[:,0:102]
Y = finaltrain.values[:,102]

x = finaltest.values[:,0:102]
y = finaltest.values[:,102]


# ### Naive Bayes Model

# In[20]:


#Multinominal Naive bayes
#Without TFIDF matrices
#Preparing a naive bayes model on training dataset


# In[22]:


from sklearn.naive_bayes import MultinomialNB as MB
from sklearn.naive_bayes import GaussianNB as GB


# In[23]:


classifier_mb = MB()
classifier_mb.fit(X,Y)
train_pred_m = classifier_mb.predict(X)
accuracy_train_m = np.mean(train_pred_m==Y)


# In[24]:


test_pred_m = classifier_mb.predict(x)
accuracy_test_m = np.mean(test_pred_m==y)


# In[26]:


print('Training accuracy is:',accuracy_train_m,'\n','Testing accuracy is:',accuracy_test_m)


# ### Gaussian Naive Bayes

# In[27]:


classifier_gb = GB()
classifier_gb.fit(X,Y)
#we need to  convert tfidf into array format which is compatible for gaussian naive bayes
train_pred_g = classifier_gb.predict(X)
accuracy_train_g = np.mean(train_pred_g==Y)


# In[28]:


test_pred_g = classifier_gb.predict(x)
accuracy_test_g = np.mean(test_pred_g==y)


# In[29]:


print('Training accuracy is:',accuracy_train_g,'\n','Testing accuracy is:',accuracy_test_g)


# ### By using PCA and Implementing rest all procedure

# In[30]:


drop_columns=['education','native','Salary']
X = salarytest1.drop(drop_columns,axis=1)


# In[31]:


y = salarytest['Salary']


# In[33]:


from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from sklearn.preprocessing import StandardScaler

from sklearn import svm
from sklearn.svm import SVC
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import classification_report

from sklearn.metrics import accuracy_score, confusion_matrix
from sklearn.model_selection import train_test_split, cross_val_score


# In[34]:


train_data.head()


# In[36]:


test_data.head()


# In[38]:


#as there are more number of columns we will go with pca method
#Scaling the data

sc = StandardScaler()
sc.fit(train_data)
train_norm = sc.transform(train_data)
train_norm


# In[39]:


#scaling the data

sc = StandardScaler()
sc.fit(test_data)
test_norm = sc.transform(test_data)
test_norm


# In[40]:


from sklearn.decomposition import PCA

train_pca = PCA(n_components = 102)
train_pca_values = train_pca.fit_transform(train_norm)
train_pca_values


# In[42]:


test_pca = PCA(n_components = 102)
test_pca_values = test_pca.fit_transform(test_norm)
test_pca_values


# In[46]:


#Selecting first 50 PCAs out of n_components=102

finaltrain1=pd.concat([pd.DataFrame(train_pca_values[:,0:50]),
                      salarytrain[['Salary']]],axis=1)
finaltrain1


# In[50]:


finaltest1=pd.concat([pd.DataFrame(train_pca_values[:,0:50]),
                      salarytest[['Salary']]],axis=1)
finaltest1


# In[51]:


#Feature encoding


# In[52]:


from sklearn.preprocessing import LabelEncoder
df_train = salarytrain.apply(LabelEncoder().fit_transform)
df_train.head()


# In[53]:


df_test = salarytest.apply(LabelEncoder().fit_transform)
df_test.head()


# In[54]:


#Train -Test split method


# In[55]:


drop_elements = ['education', 'native', 'Salary']
X = df_train.drop(drop_elements, axis=1)


# In[56]:


y = df_train['Salary']


# In[57]:


X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.33, random_state=40)


# ### Naive Bayes for Multinomial Model

# In[58]:


from sklearn.naive_bayes import MultinomialNB as MB
classifier_mb1 = MB()
classifier_mb1.fit(X_train, y_train)


# In[59]:


from sklearn.naive_bayes import BernoulliNB
from sklearn.naive_bayes import MultinomialNB as MB

#bernoulli_nb = BernoulliNB()
#bernoulli_nb.fit(X_train, y_train)

score_multinomial_train = classifier_mb1.score(X_train, y_train)
print('The accuracy of Naive Bayes is', score_multinomial_train)


# In[60]:


score_multinomial_test = classifier_mb1.score(X_test, y_test)
print('The accuracy of Naive Bayes is', score_multinomial_test)


# ### Building Gausian Naive Bayes Model

# In[61]:


#Gaussian Naive Bayes
from sklearn.naive_bayes import GaussianNB as GB

classifier_gb = GB()
classifier_gb.fit(X_train, y_train)


# In[62]:


score_gaussian_train = classifier_gb.score(X_train, y_train)
print('The accuracy of Gaussian Naive Bayes is', score_gaussian_train)


# In[63]:


score_gaussian = classifier_gb.score(X_test, y_test)
print('The accuracy of Gaussian Naive Bayes is', score_gaussian)


# In[64]:


#Finally we can conclude that their is not much difference between train and testing accuracy. So no sign of overfitting.


# In[ ]:




