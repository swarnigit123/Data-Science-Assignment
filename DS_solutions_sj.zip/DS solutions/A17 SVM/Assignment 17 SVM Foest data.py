#!/usr/bin/env python
# coding: utf-8

# ## Classification model using SVM for forest_data

# In[37]:


#import libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.svm import SVC
from sklearn.model_selection import train_test_split
from sklearn import preprocessing
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import confusion_matrix, classification_report, accuracy_score
from sklearn.model_selection import GridSearchCV


# In[5]:


data = pd.read_csv('forestfires.csv')


# In[6]:


data


# ### EDA

# In[7]:


data.shape


# In[8]:


data.info()


# In[9]:


data.describe()


# In[10]:


data.corr()


# In[11]:


plt.figure(figsize=(10,6))
sns.countplot(x = 'month', hue = 'size_category', data=data, palette='Set1')


# - From the above onservation we can say most of the forest fire broke during the month of August and September resp. and during these time the fire caused small burnt area.
# - The area for large burnt area was almost twice as compared to small burnt ara during August and September

# In[17]:


plt.figure(figsize=(10,6))
sns.countplot(x= 'day', hue = 'size_category', data=data, palette='Set1')


# - The forest caught fire mostly on sunday and friday
# - Most of the times the count of small burn area of forest is almost twice that of large burn area of forest

# In[21]:


label_encoder = preprocessing.LabelEncoder()


# In[23]:


data["month"] = label_encoder.fit_transform(data["month"])
data["day"] = label_encoder.fit_transform(data["day"])
data["size_category"] = label_encoder.fit_transform(data["size_category"])


# In[24]:


for i in data.describe().columns[:-2]:
    data.plot.scatter(i, 'area', grid=True)


# In[29]:


X = data.iloc[:,:11]
X


# In[30]:


y = data["size_category"]
y


# In[31]:


X_train, X_test, y_train, y_test = train_test_split(X,y, test_size = 0.3)


# In[32]:


X_train.shape, y_train.shape, X_test.shape, y_test.shape


# ### SVM model

# In[33]:


model = SVC()
model.fit(X_train, y_train)


# ### Predicting model

# In[34]:


y_pred = model.predict(X_test)
y_pred


# ### Model evaluation

# In[35]:


print(confusion_matrix(y_test, y_pred))


# In[36]:


print(classification_report(y_test, y_pred))


# In[38]:


acc = accuracy_score(y_test, y_pred)*100
print("Accuracy =", acc)


# ### Improving the model

# In[40]:


model_linear = SVC(kernel = "linear", random_state=40, gamma=0.1, C=1.0)
model_linear.fit(X_train,y_train)


# In[41]:


pred_test_linear = model_linear.predict(X_test)


# In[42]:


np.mean(pred_test_linear==y_test)


# In[43]:


# Kernel = poly
model_poly = SVC(kernel = "poly",random_state=40,gamma=0.1,C=1.0)
model_poly.fit(X_train,y_train)
pred_test_poly = model_poly.predict(X_test)


# In[44]:


np.mean(pred_test_poly==y_test)


# In[47]:


#kernel=rbf
model_rbf = SVC(kernel = "rbf",random_state=40,gamma=0.1,C=1.0)
model_rbf.fit(X_train,y_train)
pred_test_rbf = model_rbf.predict(X_test)


# In[48]:


np.mean(pred_test_rbf==y_test)


# In[49]:


#sigmoid
model_sig = SVC(kernel = "sigmoid",random_state=40,gamma=0.1,C=1.0)
model_sig.fit(X_train,y_train)
pred_test_sig = model_sig.predict(X_test)


# In[50]:


np.mean(pred_test_sig==y_test)


# - we get the 98% average accuray using linear kernel function

# ### Improving model using GridSearchCV

# In[51]:


param_grid = {'C': [0.1,1,10,100,1000], 'gamma': [1,0.1,0.01,0.001,0.0001], 'kernel': ['rbf','linear','poly','sigmoid']}


# In[52]:


grid = GridSearchCV(SVC(), param_grid, refit = True, verbose = 3, cv=5)


# In[53]:


grid.fit(X_train, y_train)


# In[54]:


grid.best_params_


# In[55]:


grid.best_estimator_


# In[56]:


grid_pred = grid.predict(X_test)


# In[57]:


grid_pred


# In[58]:


print(confusion_matrix(y_test, grid_pred))


# In[59]:


print(classification_report(y_test, grid_pred))


# In[60]:


np.mean(grid_pred==y_test)


# - So, using grid search method, we improved our model accuracy

# In[ ]:




