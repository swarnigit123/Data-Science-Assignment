#!/usr/bin/env python
# coding: utf-8

# ## Classification model using SVM for salary_data

# In[1]:


#Import libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')

from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import StandardScaler

from sklearn.svm import SVC
from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import train_test_split, cross_val_score

from sklearn.metrics import classification_report
from sklearn.metrics import accuracy_score, confusion_matrix


# In[2]:


Train = pd.read_csv('SalaryData_Train(1).csv')
Test = pd.read_csv('SalaryData_Test(1).csv')


# In[3]:


Train


# In[4]:


Test


# ### EDA

# In[5]:


Train.info()


# In[6]:


Train.shape


# In[7]:


Test.info()


# In[8]:


Test.shape


# In[9]:


Train.describe()


# In[10]:


Test.describe()


# In[11]:


Train[Train.isnull().any(axis=1)]


# In[12]:


Train.isnull().sum()


# In[13]:


Test[Test.isnull().any(axis=1)]


# In[14]:


Test.isnull().sum()


# In[15]:


Train['Salary'].value_counts()


# In[16]:


Test["Salary"].value_counts()


# In[17]:


pd.crosstab(Train['occupation'],Train['Salary'])


# In[18]:


pd.crosstab(Train['workclass'],Train['Salary'])


# In[19]:


pd.crosstab(Train['workclass'],Train['occupation'])


# In[20]:


sns.countplot(x='Salary',data=Train)
plt.xlabel('Salary')
plt.ylabel('count')
plt.show()
Train["Salary"].value_counts()


# In[21]:


sns.countplot(x='Salary',data=Test)
plt.xlabel('Salary')
plt.ylabel('count')
plt.show()
Train["Salary"].value_counts()


# In[22]:


sns.scatterplot(Train['occupation'],Train['workclass'],hue=Train['Salary'])


# In[23]:


pd.crosstab(Train['Salary'],Train['education']).mean().plot(kind='bar')


# In[24]:


pd.crosstab(Train['Salary'],Train['occupation']).mean().plot(kind='bar')


# In[25]:


pd.crosstab(Train['Salary'],Train['workclass']).mean().plot(kind='bar')


# In[26]:


pd.crosstab(Train['Salary'],Train['sex']).mean().plot(kind='bar')


# In[27]:


pd.crosstab(Train['Salary'],Train['relationship']).mean().plot(kind='bar')


# In[28]:


#scatter matrix to observe relationship between every column attribute
pd.plotting.scatter_matrix(Train, figsize=[20,20],diagonal='hist', alpha=1, s = 300, marker = '.',edgecolor='black')
plt.show


# In[29]:


#find categorical variables

categorical = [var for var in Train.columns if Train[var].dtype=='O']

print('There are {} categorical variables\n'.format(len(categorical)))

print('The categorical variables are :\n\n', categorical)


# In[30]:


#check for cardinality in categorical variables

for var in categorical:
    
    print(var, ' contains ', len(Train[var].unique()), ' labels')


# In[31]:


string_columns = ["workclass","education","maritalstatus","occupation","relationship","race","sex","native"]


# In[32]:


#preprocessing the data as there are categorical variables
number = LabelEncoder()
for i in string_columns:
    Train[i] = number.fit_transform(Train[i])
    Test[i] = number.fit_transform(Test[i])


# In[33]:


Train


# In[34]:


Test


# In[35]:


colnames = Train.columns
colnames


# In[36]:


x_train = Train[colnames[0:13]]
y_train = Train[colnames[13]]
x_test = Test[colnames[0:13]]
y_test = Test[colnames[13]]


# In[39]:


##Normalmization
def norm_func(i):
    x = (i-i.min())/(i.max()-i.min())
    return (x)


# In[40]:


x_train = norm_func(x_train)
x_test =  norm_func(x_test)


# ### SVM model

# In[41]:


model_linear = SVC(kernel = "linear", random_state=40, gamma=0.1, C=1.0)
model_linear.fit(x_train,y_train)


# In[42]:


pred_test_linear = model_linear.predict(x_test)


# In[43]:


np.mean(pred_test_linear==y_test)


# In[45]:


# Kernel = poly
model_poly = SVC(kernel = "poly",random_state=40,gamma=0.1,C=1.0)
model_poly.fit(x_train,y_train)
pred_test_poly = model_poly.predict(x_test)


# In[47]:


np.mean(pred_test_poly==y_test)


# In[48]:


#kernel=rbf
model_rbf = SVC(kernel = "rbf",random_state=40,gamma=0.1,C=1.0)
model_rbf.fit(x_train,y_train)
pred_test_rbf = model_rbf.predict(x_test)


# In[49]:


np.mean(pred_test_rbf==y_test)


# In[50]:


#sigmoid
model_sig = SVC(kernel = "sigmoid",random_state=40,gamma=0.1,C=1.0)
model_sig.fit(x_train,y_train)
pred_test_sig = model_sig.predict(x_test)


# In[51]:


np.mean(pred_test_sig==y_test)


# ### SVM with GridSearch

# In[52]:


#kernel=rbf
clf=SVC()
parma_grid = [{'kernel' : ["rbf"],'random_state':[40],'gamma':[0.1],'C':[1.0]}]


# In[53]:


gsv = GridSearchCV(clf,parma_grid,cv=10)
gsv.fit(x_train, y_train)


# In[54]:


gsv.best_params_, gsv.best_score_


# In[55]:


clf = SVC(C= 15, gamma = 50)
clf.fit(x_train, y_train)
y_pred = clf.predict(x_test)


# In[56]:


acc = accuracy_score(y_test, y_pred)*100
print("Accuracy =", acc)


# In[59]:


confusion_matrix(y_test, y_pred)


# In[60]:


#kernel = linear
clf =SVC()
parma_grid = [{'kernel': ['linear'],'random_state':[40],'gamma':[0.1],'C':[1.0]}]


# In[61]:


gsv = GridSearchCV(clf,parma_grid,cv=10)
gsv.fit(x_train, y_train)


# In[62]:


gsv.best_params_ , gsv.best_score_


# In[63]:


clf = SVC(C=15, gamma = 50)
clf.fit(x_train, y_train)
y_pred = clf.predict(x_test)


# In[64]:


acc = accuracy_score(y_test, y_pred)*100
print("Accuracy =", acc)


# In[65]:


confusion_matrix(y_test, y_pred)


# In[66]:


# kernel = poly
clf = SVC()
parma_grid = [{'kernel': ['poly'],'random_state':[40],'gamma':[0.1],'C':[1.0]}]


# In[67]:


gsv = GridSearchCV(clf, parma_grid, cv=10)
gsv.fit(x_train, y_train)


# In[68]:


gsv.best_params_ , gsv.best_score_


# In[69]:


clf = SVC(C=15, gamma=50)
clf.fit(x_train, y_train)
y_pred = clf.predict(x_test)


# In[70]:


acc = accuracy_score(y_test, y_pred)*100
print("Accuracy = ", acc)


# In[71]:


# kernel = sigmoid
clf = SVC()
parma_grid = [{'kernel': ['sigmoid'], 'random_state':[40], 'gamma':[0.1], 'C':[1.0]}]


# In[72]:


gsv = GridSearchCV(clf, parma_grid, cv=10)
gsv.fit(x_train, y_train)


# In[73]:


gsv.best_params_ , gsv.best_score_


# In[74]:


clf = SVC(C =15, gamma=50)
clf.fit(x_train, y_train)
y_pred = clf.predict(x_test)


# In[76]:


acc = accuracy_score(y_test, y_pred)*100
print("Accuracy =", acc)


# In[ ]:




