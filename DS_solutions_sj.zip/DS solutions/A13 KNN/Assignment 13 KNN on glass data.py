#!/usr/bin/env python
# coding: utf-8

# ## KNN on glass data

# In[1]:


#import libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from collections import Counter
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import classification_report,confusion_matrix,accuracy_score
from sklearn.model_selection import GridSearchCV, KFold, cross_val_score,train_test_split
import warnings
warnings.filterwarnings('ignore')


# In[2]:


#load the dataset
glass = pd.read_csv('glass.csv')
glass.head()


# In[3]:


glass.tail()


# ### EDA

# In[4]:


glass.shape


# In[5]:


glass.info()


# In[6]:


glass.describe()


# In[7]:


glass.isnull().any()


# In[8]:


glass .isnull().sum()


# In[9]:


glass['Type'].value_counts()


# In[10]:


glass['Type'].unique()


# In[11]:


glass['Type'].value_counts().sort_index(ascending=True)


# In[12]:


glass[glass.duplicated()]


# In[13]:


glass_df = glass.drop_duplicates()
glass_df


# In[14]:


corr = glass_df.corr()
corr


# In[15]:


plt.figure(figsize=(8,8))
sns.pairplot(glass,hue = 'Type', palette = 'coolwarm')
plt.show


# In[16]:


#Correlation matrics

fig, ax = plt.subplots(figsize=(15,10))
sns.heatmap(glass.corr(), annot=True, fmt='.1g', cmap="viridis", cbar=False, linewidths=0.5, linecolor='black')


# In[17]:


#we can notice that Ca and K values don,t affect Type that much
#Also Caa and RI are highly correlated, this means using only RI is enough
#So we can go ahead and drop Ca and also aaak


# In[18]:


#Scatter plot for two features
sns.scatterplot(glass_df['RI'],glass_df['Na'],hue=glass_df['Type'])


# In[19]:


x = glass_df.drop('Type',axis=1)
y = glass_df[['Type']]


# In[20]:


x_train,x_test,y_train,y_test = train_test_split(x,y,test_size=0.3, random_state=0)


# In[21]:


print("Shape of X_train: ",x_train.shape)
print("Shape of X_test: ", x_test.shape)
print("Shape of y_train: ",y_train.shape)


# In[24]:


from sklearn.preprocessing import StandardScaler
sc= StandardScaler()
x_train = sc.fit_transform(x_train)
x_test = sc.transform(x_test)


# ### Grid search

# In[25]:


#for chosing best K value


# In[26]:


n_neighbors = np.array([2*i+1 for i in range(1,20)])
param_grid = dict(n_neighbors = n_neighbors)
n_neighbors


# In[29]:


model = KNeighborsClassifier()
grid = GridSearchCV(estimator=model, param_grid=param_grid, cv=10)
grid.fit(x,y)


# In[30]:


print(grid.best_score_)
print(grid.best_params_)


# In[31]:


#CV results


# In[33]:


import matplotlib.pyplot as plt
get_ipython().run_line_magic('matplotlib', 'inline')
#choose k between 1 to 40
k_range = np.array([2*i+1 for i in range(1,20)])
k_scores = []
#use iteration to calculator different k in models, then return the average accuracy based on the cross validation
for k in k_range:
    knn = KNeighborsClassifier(n_neighbors=k)
    scores = cross_val_score(knn, x,y, cv=10)
    k_scores.append(scores.mean())
#plot to see clearly
plt.figure(figsize=(12,8))
plt.plot(k_range, k_scores)
plt.xlabel('Value K for KNN')
plt.ylabel("Cross-Validates Accuracy")
plt.xticks(k_range)
plt.show()


# In[34]:


glass_df


# In[35]:


glass_df1 = glass_df.iloc[:,0:9]
glass_df1


# In[36]:


array = glass_df1.values
array


# In[37]:


#Normalization function
from sklearn.preprocessing import StandardScaler

stscaler = StandardScaler().fit(array)
X = stscaler.transform(array)


# In[38]:


X


# In[39]:


#Removing last columns
glass_df_knn = pd.DataFrame(X, columns=glass_df.columns[:-1])
glass_df_knn


# In[40]:


x = glass_df_knn
y = glass_df['Type']


# In[41]:


x


# In[42]:


y


# In[43]:


x_train, x_test, y_train, y_test = train_test_split(x,y, test_size=0.3, random_state = True)


# In[44]:


x_train


# In[45]:


x_test


# In[47]:


y_train


# In[48]:


y_test


# ### KNN Model

# In[49]:


model = KNeighborsClassifier(n_neighbors=3)
model.fit(x_train,y_train)


# In[50]:


#predicting on test data
preds = model.predict(x_test)
pd.Series(preds).value_counts()


# In[51]:


pd.crosstab(y_test,preds)


# In[52]:


print('Accuracy', accuracy_score(y_test,preds)*100)


# In[53]:


model.score(x_train,y_train)


# In[54]:


print(classification_report(y_test,preds))


# ### Grid search for Algorithm tuning

# In[55]:


n_neighbors = np.array(range(1,20))
param_grid = dict(n_neighbors=n_neighbors)


# In[56]:


model = KNeighborsClassifier()
grid = GridSearchCV(estimator=model, param_grid=param_grid)
grid.fit(x,y)


# In[57]:


print(grid.best_score_)
print(grid.best_params_)


# In[58]:


#Visualizing cv results


# In[59]:


k_values = np.arange(1,20)
train_accuracy = []
test_accuracy = []

for i, k in enumerate(k_values):
    # k from 1 to 20(exclude)
    knn = KNeighborsClassifier(n_neighbors=k)
    # Fit with knn
    knn.fit(x_train,y_train)
    #train accuracy
    train_accuracy.append(knn.score(x_train, y_train))
    # test accuracy
    test_accuracy.append(knn.score(x_test, y_test))
# Plot
plt.figure(figsize=[13,8])
plt.plot(k_values, test_accuracy, label = 'Testing Accuracy')
plt.plot(k_values, train_accuracy, label = 'Training Accuracy')
plt.legend()
plt.title('-value VS Accuracy')
plt.xlabel('Number of Neighbors')
plt.ylabel('Accuracy')
plt.xticks(k_values)
plt.savefig('graph.png')
plt.show()
print("Best accuracy is {} with K = {}".format(np.max(test_accuracy),1+test_accuracy.index(np.max(test_accuracy))))


# In[ ]:




