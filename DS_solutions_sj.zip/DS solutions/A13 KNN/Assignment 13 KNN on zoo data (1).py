#!/usr/bin/env python
# coding: utf-8

# ## KNN on zoo data

# In[3]:


#import libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from collections import Counter
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import classification_report,confusion_matrix,accuracy_score
from sklearn.model_selection import GridSearchCV, KFold,cross_val_score,train_test_split


# In[4]:


#import dataset
zoo = pd.read_csv('zoo.csv')
zoo.head()


# In[5]:


zoo.tail()


# ### EDA and Data Visualization

# In[6]:


zoo.shape


# In[7]:


zoo.info()


# In[8]:


zoo.describe()


# In[9]:


zoo['animal name'].value_counts()


# In[10]:


color_list = [("red" if i ==1 else "blue" if i ==0 else "yellow" ) for i in zoo.aquatic]


# In[11]:


# With this set function we find unique values in a list...
unique_list = list(set(color_list))
unique_list


# In[14]:


pd.plotting.scatter_matrix(zoo.iloc[:,:6],
                                       c=color_list,
                                       figsize= [20,20],
                                       diagonal='hist',
                                       alpha=1,
                                       s = 300,
                                       marker = '*',
                                       edgecolor= "black")
plt.show()


# In[15]:


#check if there are duplicates in animal_name
duplicates = zoo['animal name'].value_counts()
duplicates[duplicates > 1]


# In[16]:


frog = zoo[zoo['animal name'] == 'frog']
frog


# In[17]:


# observation: find that one frog is venomous and another one is not 
# change the venomous one into frog2 to seperate 2 kinds of frog 
zoo['animal name'][(zoo['venomous'] == 1 )& (zoo['animal name'] == 'frog')] = "frog2"


# In[18]:


zoo['venomous'].value_counts()


# In[19]:


# Lets see how many animals live under water. i.e aquatic
# lets find out all the aquatic animals.
zoo.aquatic.value_counts() # only 36 aquatic animals are there.
# lets see there class


# In[20]:


zoo[zoo['aquatic']==1].type.value_counts()


# In[21]:


sns.countplot(x="aquatic", data=zoo)
plt.xlabel("aquatic")
plt.ylabel("Count")
plt.show()
zoo.loc[:,'aquatic'].value_counts()


# ### Split Train and Test

# In[25]:


from sklearn.model_selection import train_test_split
X = zoo.iloc[:,1:16]   #Training data
y = zoo.iloc[:,16]     #Test data
X_train, X_test, y_train, y_test = train_test_split(X,y, test_size=0.3, random_state=True)


# In[26]:


X_train


# In[27]:


X_test


# In[28]:


y_train


# In[29]:


y_test


# ### KNN Model

# In[30]:


num_folds = 10
kfold = KFold(n_splits=10)


# In[32]:


model = KNeighborsClassifier(n_neighbors=3)
model.fit(X_train,y_train)


# In[33]:


#Predicting on test data
preds = model.predict(X_test)
pd.Series(preds).value_counts()


# In[34]:


pd.crosstab(y_test,preds)


# In[35]:


#Accuracy
np.mean(preds==y_test)


# In[36]:


print("Accuracy", accuracy_score(y_test,preds)*100)


# In[37]:


model.score(X_train,y_train)


# ### Cross Validation Score

# In[38]:


results = cross_val_score(model, X, y, cv=kfold)


# In[39]:


print(results.mean()*100)


# In[40]:


print(results.std()*100)


# ### Grid Search for Algorithm Tuning

# In[41]:


n_neighbors = np.array(range(1,40))
param_grid = dict(n_neighbors=n_neighbors)


# In[42]:


model = KNeighborsClassifier()
grid = GridSearchCV(estimator=model, param_grid=param_grid)
grid.fit(X, y)


# In[43]:


print(grid.best_score_)
print(grid.best_params_)


# In[44]:


k_values = np.arange(1,25)
train_accuracy = []
test_accuracy = []

for i, k in enumerate(k_values):
    # k from 1 to 25(exclude)
    knn = KNeighborsClassifier(n_neighbors=k)
    # Fit with knn
    knn.fit(X_train,y_train)
    #train accuracy
    train_accuracy.append(knn.score(X_train,y_train))
    # test accuracy
    test_accuracy.append(knn.score(X_test,y_test))
# Plot
plt.figure(figsize=[13,8])
plt.plot(k_values, test_accuracy, label = 'Testing Accuracy')
plt.plot(k_values, train_accuracy, label = 'Training Accuracy')
plt.legend()
plt.title('-value VS Accuracy')
plt.xlabel('Number of Neighbors')
plt.ylabel('Accuracy')
plt.xticks(k_values)
plt.savefig('graph.png')
plt.show()
print("Best accuracy is {} with K = {}".format(np.max(test_accuracy),1+test_accuracy.index(np.max(test_accuracy))))


# In[ ]:




