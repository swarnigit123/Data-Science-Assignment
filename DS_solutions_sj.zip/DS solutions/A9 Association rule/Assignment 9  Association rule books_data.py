#!/usr/bin/env python
# coding: utf-8

# ## Assignment 9 Association rules book_data

# In[1]:


conda install -c conda-forge mlxtend


# In[2]:


#import libraries
import pandas as pd
import numpy as np
from mlxtend.frequent_patterns import apriori,association_rules
from mlxtend.preprocessing import TransactionEncoder


# In[3]:


#Load books Datatset
book = pd.read_csv('book.csv')
book.head()


# In[4]:


book.shape


# ### Aprori Algorithm

# In[5]:


#Apriori Algorithm for min support = 0.1 and confidence


# In[6]:


frequent_itemsets = apriori(book, min_support=0.1, use_colnames=True)


# In[7]:


frequent_itemsets


# In[8]:


frequent_itemsets = apriori(book, min_support=0.1, use_colnames=True)
frequent_itemsets['length'] = frequent_itemsets['itemsets'].apply(lambda x: len(x))


# In[9]:


frequent_itemsets


# In[10]:


#Rules when min_support = 0.1 and min_threshold for lift is 0.6


# In[11]:


rules = association_rules(frequent_itemsets, metric='lift', min_threshold=0.7)
rules


# In[12]:


#sort thr ruled by lift
rules.sort_values('lift',ascending = False)


# In[13]:


import matplotlib.pyplot as plt


# In[14]:


plt.scatter(rules['support'], rules['confidence'], alpha=0.5)
plt.xlabel('support')
plt.ylabel('confidence')
plt.title("Support vs Confidence")
plt.show()


# In[15]:


plt.scatter(rules['support'], rules['lift'], alpha=0.5)
plt.xlabel('support')
plt.ylabel('lift')
plt.title("Support vs lift")
plt.show()


# In[16]:


#Rules when min_support = 0.1 and min_threshold for confidence is 0.7


# In[17]:


rules1 = association_rules(frequent_itemsets, metric='confidence', min_threshold=0.7)
rules1


# In[18]:


plt.scatter(rules1['support'], rules1['confidence'], alpha=0.5)
plt.xlabel('support')
plt.ylabel('confidence')
plt.title('Support vs Confidence')
plt.show()


# In[19]:


plt.scatter(rules1['support'], rules1['lift'], alpha=0.5)
plt.xlabel('support')
plt.ylabel('lift')
plt.title("Support vs lift")
plt.show()


# In[20]:


rules1 = rules1.sort_values(['confidence', 'lift'], ascending = [False, False])


# In[21]:


rules1


# In[ ]:





# In[ ]:





# In[22]:


#Apriori algorithm for min_support = 0.2


# In[23]:


frequent_itemsets1 = apriori(book, min_support=0.2, use_colnames=True)
frequent_itemsets1


# In[24]:


frequent_itemsets1 = apriori(book, min_support = 0.2, use_colnames=True)
frequent_itemsets1['length'] = frequent_itemsets1['itemsets'].apply(lambda x: len(x))
frequent_itemsets1


# In[25]:


#rules when min_support = 0.2 and min_threshold for lift is 0.7


# In[26]:


rules2 = association_rules(frequent_itemsets1, metric = 'lift', min_threshold=0.7)


# In[27]:


rules2


# In[28]:


rules2[rules2.lift>1]


# In[29]:


plt.scatter(rules2['support'], rules2['confidence'], alpha=0.5)
plt.xlabel('support')
plt.ylabel('confidence')
plt.title('Support vs Confidence')
plt.show()


# In[30]:


plt.scatter(rules2['support'], rules2['lift'], alpha=0.5)
plt.xlabel('support')
plt.ylabel('lift')
plt.title("Support vs lift")
plt.show()


# In[31]:


#Rules when min_support = 0.1 and min_threshold for confidence is 0.5


# In[32]:


rules3 = association_rules(frequent_itemsets1, metric="confidence", min_threshold=0.5)
rules3


# In[33]:


rules3 = rules3.sort_values(['confidence', 'lift'], ascending = [False, False])
rules3


# In[34]:


plt.scatter(rules3['support'], rules3['confidence'], alpha=0.5)
plt.xlabel('support')
plt.ylabel('confidence')
plt.title('Support vs Confidence')
plt.show()


# In[35]:


plt.scatter(rules3['support'], rules3['lift'], alpha=0.5)
plt.xlabel('support')
plt.ylabel('lift')
plt.title('Support vs lift')
plt.show()


# In[36]:


rules3[rules3.lift>1]


# In[ ]:





# In[37]:


#Apriori algorithm for min_support = 0.25


# In[38]:


frequent_itemsets2 = apriori(book, min_support = 0.25,use_colnames=True)
frequent_itemsets2


# In[39]:


frequent_itemsets2 = apriori(book, min_support = 0.25, use_colnames=True)
frequent_itemsets2['length'] = frequent_itemsets2['itemsets'].apply(lambda x: len(x))
frequent_itemsets2


# In[40]:


#rules when min_support = 0.25 and min_threshold for lift is 0.7


# In[41]:


rules4 = association_rules(frequent_itemsets2, metric='lift', min_threshold = 0.7)
rules4


# In[42]:


rules4.sort_values('lift', ascending = False)


# In[43]:


#Rules when min_support=0.25 and min_threshold for confidence is 0.6


# In[44]:


rules5 = association_rules(frequent_itemsets2, metric='confidence', min_threshold=0.6)
rules5


# In[45]:


rules5 = rules5.sort_values(['confidence', 'lift'], ascending = [False,False])
rules5


# In[ ]:





# In[ ]:




