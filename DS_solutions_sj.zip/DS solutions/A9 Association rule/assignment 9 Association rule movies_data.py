#!/usr/bin/env python
# coding: utf-8

# ## Association rule on movies_data

# In[1]:


#import libraries
import pandas as pd
from mlxtend.frequent_patterns import apriori, association_rules
from mlxtend.preprocessing import TransactionEncoder


# In[2]:


#Load datasets
movies = pd.read_csv('my_movies.csv')


# In[3]:


movies.head()


# ### Apriori Algorithm

# In[4]:


#Apriori algorithm for min_support = 0.1 and confidence


# In[5]:


df=pd.get_dummies(movies)


# In[6]:


df.head()


# In[7]:


frequent_itemsets = apriori(df, min_support=0.1, use_colnames=True)
frequent_itemsets


# In[8]:


frequent_itemsets = apriori(df, min_support = 0.1, use_colnames=True)
frequent_itemsets['length'] = frequent_itemsets['itemsets'].apply(lambda x: len(x))
frequent_itemsets


# In[9]:


#Rules when min_support = 0.1 and min_threshold for lift is 0.7


# In[10]:


rules = association_rules(frequent_itemsets, metric='lift', min_threshold= 0.5)
rules


# In[11]:


rules.sort_values('lift',ascending = False)


# In[12]:


import matplotlib.pyplot as plt


# In[41]:


plt.scatter(rules['support'], rules['confidence'], alpha=0.5)
plt.xlabel('support')
plt.ylabel('confidence')
plt.title('Support vs Confidence')
plt.show()


# In[42]:


plt.scatter(rules['support'], rules['lift'], alpha=0.5)
plt.xlabel('support')
plt.ylabel('lift')
plt.title('Support vs lift')
plt.show()


# In[14]:


#Rules when min_support = 0.1 and min_threshold for confidence is 0.7


# In[15]:


rules1 = association_rules(frequent_itemsets, metric='confidence', min_threshold = 0.5)
rules1


# In[43]:


plt.scatter(rules1['support'], rules1['confidence'], alpha=0.5)
plt.xlabel('support')
plt.ylabel('confidence')
plt.title('Support vs Confidence')
plt.show()


# In[44]:


plt.scatter(rules1['support'], rules1['lift'], alpha=0.5)
plt.xlabel('support')
plt.ylabel('lift')
plt.title('Support vs lift')
plt.show()


# In[17]:


rules1 = rules1.sort_values(['confidence','lift'], ascending=[False, False])
rules1


# In[18]:


#Apriori algorithm for min_support = 0.2


# In[19]:


frequent_itemsets1 = apriori(df, min_support=0.2, use_colnames=True)
frequent_itemsets1


# In[20]:


frequent_itemset1 = apriori(df, min_support = 0.2, use_colnames=True)
frequent_itemsets1['length'] = frequent_itemsets1['itemsets'].apply(lambda x: len(x))
frequent_itemsets1


# In[21]:


#Rules when min_support = 0.2 and min_threshold for lift is 0.7


# In[22]:


rules2 = association_rules(frequent_itemsets1, metric='lift', min_threshold=0.7)
rules2


# In[23]:


rules2[rules2.lift>1]


# In[49]:


plt.scatter(rules2['support'], rules2['confidence'], alpha=0.5)
plt.xlabel('support')
plt.ylabel('confidence')
plt.title('Support vs Confidence')
plt.show()


# In[50]:


plt.scatter(rules2['support'], rules2['lift'], alpha=0.5)
plt.xlabel('support')
plt.ylabel('lift')
plt.title('Support vs lift')
plt.show()


# In[25]:


#Rules when min_support = 0.2 and min_threshold for confidence is 0.7


# In[26]:


rules3 = association_rules(frequent_itemsets1, metric='confidence', min_threshold=0.7)
rules3


# In[27]:


rules3= rules3.sort_values(['confidence', 'lift'], ascending =[False, False])
rules3


# In[47]:


plt.scatter(rules3['support'], rules3['confidence'], alpha=0.5)
plt.xlabel('support')
plt.ylabel('confidence')
plt.title('Support vs Confidence')
plt.show()


# In[48]:


plt.scatter(rules3['support'], rules3['lift'], alpha=0.5)
plt.xlabel('support')
plt.ylabel('lift')
plt.title('Support vs lift')
plt.show()


# In[29]:


rules3[rules3.lift>1]


# In[ ]:





# In[30]:


#Apriori algorithm for min_support = 0.25


# In[31]:


frequent_itemsets2 = apriori(df, min_support=0.25, use_colnames=True)
frequent_itemsets2


# In[32]:


frequent_itemsets2 = apriori(df, min_support = 0.25, use_colnames=True)
frequent_itemsets2['length'] = frequent_itemsets2['itemsets'].apply(lambda x: len(x))
frequent_itemsets2


# In[33]:


#Rules when min_support= 0.25 and min_threshold for lift is 0.7


# In[34]:


rules4 = association_rules(frequent_itemsets2, metric='lift', min_threshold=0.7)
rules4


# In[35]:


rules4.sort_values('lift',ascending = False)


# In[ ]:





# In[36]:


#Rules when min_support = 0.25 and min_threshold for confidence is 0.7


# In[37]:


rules5 = association_rules(frequent_itemsets2, metric='confidence', min_threshold=0.7)
rules5


# In[38]:


rules5 = rules5.sort_values(['confidence', 'lift'], ascending =[False, False])
rules5


# In[51]:


plt.scatter(rules5['support'], rules5['confidence'], alpha=0.5)
plt.xlabel('support')
plt.ylabel('confidence')
plt.title('Support vs Confidence')
plt.show()


# In[52]:


plt.scatter(rules5['support'], rules5['lift'], alpha=0.5)
plt.xlabel('support')
plt.ylabel('lift')
plt.title('Support vs lift')
plt.show()


# In[ ]:




