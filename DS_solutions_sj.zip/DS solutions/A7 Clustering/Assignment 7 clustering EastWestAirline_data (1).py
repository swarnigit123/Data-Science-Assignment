#!/usr/bin/env python
# coding: utf-8

# ### Clustering on Eastwestairlines_data

# ### Heirarchical clustering

# In[1]:


#import libraries
import pandas as pd
import numpy as np
import scipy.cluster.hierarchy as sch
from sklearn.cluster import AgglomerativeClustering
import matplotlib.pyplot as plt
import seaborn as sns


# In[2]:


EWAirlines = pd.read_csv("EastWestAirlines_data")
EWAirlines


# In[3]:


EWAirlines.info()


# In[4]:


#Normalizing function
def norm_func(i):
    x = (i-i.min())/(i.max()-i.min())
    return (x)


# In[5]:


#Normalized dataframe considering only numerical part
df_norm = norm_func(EWAirlines.iloc[:,1:])


# In[6]:


#create dendrogram
plt.figure(figsize=(15,7))
dendrogram = sch.dendrogram(sch.linkage(df_norm, method ='complete'))


# In[7]:


#Create clusters
hclusters = AgglomerativeClustering(n_clusters = 5, affinity = 'euclidean', linkage='ward')
hclusters


# In[8]:


y = pd.DataFrame(hclusters.fit_predict(df_norm),columns=['clusterid'])
y['clusterid'].value_counts()


# In[9]:


#Adding clusters to dataset
EWAirlines['hclusterid']= hclusters.labels_


# In[10]:


EWAirlines


# In[11]:


#Plot clusters
plt.figure(figsize=(10,7))
plt.scatter(EWAirlines['hclusterid'],EWAirlines['Balance'], c=hclusters.labels_)


# ### K-Means clustering

# In[12]:


from sklearn.cluster import KMeans


# In[13]:


#Normalization function
from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()


# In[14]:


EWAirlines_df =scaler.fit_transform(EWAirlines.iloc[:,1:])


# In[15]:


# How to find optimum number of  cluster
#The K-means algorithm aims to choose centroids that minimise the inertia, or within-cluster sum-of-squares criterion:


# In[16]:


wcss = []
for i in range(1,11):
    kmeans = KMeans(n_clusters=i, random_state=0)
    kmeans.fit(EWAirlines_df)
    wcss.append(kmeans.inertia_)
    
plt.plot(range(1,11),wcss)
plt.title('Elbow Method')
plt.xlabel('Number of clusters')
plt.ylabel('WCSS')
plt.show()


# In[17]:


#Build cluster algorithm
clusters_new = KMeans(6, random_state =  22000)
clusters_new.fit(EWAirlines_df)


# In[18]:


clusters_new.labels_


# In[19]:


#Assign clusters to the dataset
EWAirlines['kclusterid'] = clusters_new.labels_


# In[20]:


#standardized values
clusters_new.cluster_centers_


# In[21]:


EWAirlines


# In[22]:


EWAirlines.groupby('kclusterid').agg(['mean']).reset_index()


# ### DBSCAN Clustering

# In[23]:


from sklearn.cluster import DBSCAN


# In[24]:


EWAirlines.head()


# In[25]:


EWAirlines.info()


# In[26]:


EWAirlines.drop(['ID#'],axis=1,inplace=True)


# In[27]:


array = EWAirlines.values


# In[28]:


array


# In[29]:


from sklearn.preprocessing import StandardScaler
stscaler = StandardScaler().fit(array)


# In[30]:


X = stscaler.transform(array)
X


# In[31]:


dbscan =DBSCAN(eps=2, min_samples=12)
dbscan.fit(X)


# In[32]:


#Noisy samples are given label -1
dbscan.labels_


# In[34]:


c1 = pd.DataFrame(dbscan.labels_,columns=['cluster'])
c1


# In[37]:


EWAirlines['dbclusterid'] = dbscan.labels_
EWAirlines


# In[ ]:




