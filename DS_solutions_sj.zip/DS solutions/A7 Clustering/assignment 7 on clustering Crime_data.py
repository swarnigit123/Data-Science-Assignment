#!/usr/bin/env python
# coding: utf-8

# ## Clustering on crime_data

# ### Hierarchical Clustering 

# In[1]:


#Import libraries
import pandas as pd
import numpy as np
import scipy.cluster.hierarchy as sch
from sklearn.cluster import AgglomerativeClustering
import matplotlib.pyplot as plt
import seaborn as sn


# In[2]:


#Load data
crime_data = pd.read_csv("crime_data.csv") 


# In[3]:


crime_data.head()


# In[4]:


#Normalization function
def norm_func(i):
    x = (i-i.min())/(i.max()-i.min())
    return (x)


# In[5]:


#Creating Normalized dataframe considering only numerical  columns
df_norm = norm_func(crime_data.iloc[:,1:])
df_norm


# In[6]:


#create dendrogram
dendrogram = sch.dendrogram(sch.linkage(df_norm, method = 'complete'))


# In[7]:


#Creating clusters
hc = AgglomerativeClustering(n_clusters = 4, affinity = 'euclidean', linkage = 'single')


# In[8]:


y_hc = hc .fit_predict(df_norm)
Clusters = pd.DataFrame(y_hc, columns = ['Clusters'])


# In[9]:


Clusters


# In[10]:


#Assign clusters to dataset
crime_data['h_clusterid']=hc.labels_
crime_data


# ### K-means Hierarchical Clustering 

# In[11]:


#import libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans


# In[12]:


#Normalizing function
from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()
crime_scaled = scaler.fit_transform(crime_data.iloc[:,1:])


# In[13]:


# How to find optimum number of cluster
# the k-means algorithm aims to choose centroids that minimize the inertia, or within clusters sum-of-squares criterion 


# In[14]:


#Elbow curve
wcss = []
for i in range(1, 11):
    kmeans = KMeans(n_clusters = i,random_state=0)
    kmeans.fit(crime_scaled)
    wcss.append(kmeans.inertia_)
    
plt.plot(range(1,11),wcss)
plt.title('Elbow Method')
plt.xlabel('Number of clusters')
plt.ylabel('WCSS')
plt.show()


# In[15]:


#Building Cluster algorithm
from sklearn.cluster import KMeans
clusters_new = KMeans(4, random_state=55)
clusters_new.fit(df_norm)


# In[16]:


clusters_new.labels_


# In[33]:


#Assign clusters to dataset
crime_data['kclusterid'] = clusters_new.labels_


# In[34]:


clusters_new.cluster_centers_


# In[35]:


crime_data.groupby('clusterid_new').agg(['mean']).reset_index()


# In[36]:


crime_data


# ## DBSCAN

# In[21]:


crime_data.info()


# In[22]:


crime_data.drop(['Unnamed: 0'],axis=1, inplace=True)


# In[23]:


array = crime_data.values


# In[24]:


array


# In[25]:


from sklearn.cluster import DBSCAN
from sklearn.preprocessing import StandardScaler


# In[26]:


stscaler = StandardScaler().fit(array)
X = stscaler.transform(array)


# In[27]:


X


# In[28]:


#Build model
dbscan = DBSCAN(eps=2, min_samples = 5)
dbscan.fit(X)


# In[29]:


#Noisy samples are given the label -1
dbscan.labels_


# In[30]:


c1 = pd.DataFrame(dbscan.labels_,columns =['cluster'])


# In[31]:


c1


# In[32]:


pd.concat([crime_data,c1],axis=1)


# In[ ]:





# In[ ]:




