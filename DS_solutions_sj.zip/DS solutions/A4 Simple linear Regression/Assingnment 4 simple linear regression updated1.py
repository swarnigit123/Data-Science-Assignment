#!/usr/bin/env python
# coding: utf-8

# ### Prediction model for salary_hike

# In[28]:


#import libraries
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt


# In[2]:


#Load salary data
salary = pd.read_csv("Salary_Data.csv")
salary


# ### EDA and Data Visualization

# In[3]:


salary.shape


# In[4]:


salary.info()


# In[5]:


salary.describe()


# In[6]:


salary.info()


# In[7]:


sns.boxplot(salary['YearsExperience'], orient = 'h')


# - The data for Year Experience is skewed right.
# - All the observations lies in the intervals of approximately 3 to 8
# - We can say that the median years of experience is 5.2 years.

# In[8]:


sns.distplot(salary['YearsExperience'])


# In[9]:


sns.boxplot(salary['Salary'])


# - The onservations for Salary lies nearly between 57000 to 110000.
# - The data is skewed towars right side.
# - The median Salary is nearly 65000.

# In[10]:


sns.distplot(salary['Salary'])


# ### Correlation anlysis

# In[11]:


salary.corr()


# In[12]:


sns.regplot(x="YearsExperience", y="Salary",data=salary);


# - There is a strong relation between both variables
# - so we can build prediction model

# ### Model Building

# In[13]:


import statsmodels.formula.api as smf
model = smf.ols("Salary~YearsExperience",data=salary).fit()


# In[14]:


model.params


# In[15]:


model.tvalues, model.pvalues


# In[16]:


model.rsquared


# In[17]:


model.summary()


# - The R-squared is greater than 0.85 so we can use this model for prediction

# ### Model prediction

# In[18]:


#Predict for newdata
#add new data
newdata = pd.Series([11,12,12.5,13,13.5,14,15])


# In[19]:


#create dataframe for newdata
data_pred = pd.DataFrame(newdata,columns=["YearsExperience"])
data_pred


# In[20]:


#predict for newdata
model.predict(data_pred)


# In[21]:


model.predict(salary)


# In[23]:


pred = model.predict(salary.iloc[:,0])
pred


# In[24]:


model.resid
model.resid_pearson


# In[26]:


RMSE = np.sqrt(np.mean((np.array(salary['YearsExperience'])- np.array(pred))**2))
RMSE


# In[29]:


plt.scatter(x=salary['YearsExperience'],y=salary['Salary'],color='blue')
plt.plot(salary['YearsExperience'],pred,color='red')
plt.xlabel("YearsExperience")
plt.ylabel("Salary")


# In[32]:


df_new = pd.DataFrame({"YearsExperience":[10,12,11,10.5]})
df_new


# In[33]:


model.predict(df_new)


# In[ ]:





# In[ ]:





# In[ ]:





#  ### Predict delivery time using sorting time
# 

# In[35]:


#import libraries
import pandas as pd
import numpy as np
import seaborn as sns


# In[36]:


time_data = pd.read_csv("delivery_time.csv")
time_data


# ### EDA and Data visualization

# In[37]:


time_data.shape


# In[38]:


time_data.head()


# In[39]:


time_data.info()


# In[40]:


time_data.describe()


# In[41]:


#Renaming the columns
time_data = time_data.rename({'Delivery Time':'delivery_time','Sorting Time':'sorting_time'},axis=1)


# In[42]:


time_data.head()


# In[43]:


sns.boxplot(time_data['delivery_time'], orient = 'h')


# - The data for Delivery time is skewed left.
# - All the observations lies in the intervals of approximately 13 to 20
# - We can say that the median delivery time is around 18-19.

# In[44]:


sns.distplot(time_data['delivery_time'])


# - The distribution of 'Delivery Time' data is slightly more on the left of the curve 

# In[45]:


sns.boxplot(time_data['sorting_time'], orient='h')


# - The observations for Sorting Time lies nearly between 4 to 8.
# - It means the Sorting Time data is symmetric and skewed.
# - The median sorting time is approximately around 6.

# In[46]:


sns.distplot(time_data['sorting_time'])


# In[47]:


sns.pairplot(time_data)


# ### Correlation analysis

# In[48]:


time_data.corr()


# In[49]:


sns.regplot(x="sorting_time", y="delivery_time",data=time_data)


# ### Model Building

# In[51]:


import statsmodels.formula.api as smf
model1 = smf.ols("delivery_time~sorting_time",data=time_data).fit()
model1


# ### Model testing

# In[52]:


model1.params


# In[53]:


model1.tvalues, model.pvalues


# In[54]:


model1.summary()


# In[55]:


model1.rsquared


# ### Model Prediction

# In[56]:


newdata1 = pd.Series([9,5,7,9,6,5])


# In[57]:


data_pred1 = pd.DataFrame(newdata1,columns=['sorting_time'])


# In[58]:


data_pred1


# In[59]:


model1.predict(data_pred1)


# In[60]:


model1.predict(time_data)


# In[61]:


pred = model1.predict(time_data)


# In[62]:


pred


# In[63]:


model1.resid
model1.resid_pearson


# In[65]:


RMSE = np.sqrt(np.mean((np.array(time_data['sorting_time'])- np.array(pred))**2))
RMSE


# In[66]:


model1 = smf.ols("delivery_time~np.log(sorting_time)", data = time_data).fit()


# In[68]:


model1.summary()


# In[69]:


RMSE_log = np.sqrt(np.mean((np.array(time_data['sorting_time'])- np.array(pred))**2))
RMSE_log


# In[70]:


model2 = smf.ols("np.log(delivery_time)~sorting_time", data= time_data).fit()


# In[71]:


model2.summary()


# In[72]:


RMSE_log = np.sqrt(np.mean((np.array(time_data['sorting_time'])- np.array(pred))**2))
RMSE_log


# In[73]:


model3 = smf.ols("np.log(delivery_time)~np.log(sorting_time)", data= time_data).fit()


# In[74]:


model3.summary()


# In[77]:


actual = time_data.delivery_time
pred = model3.predict(time_data)
residual = actual - pred


# In[78]:


pred


# In[80]:


newdata = pd.DataFrame({'sorting_time':[10,6,5,7,8]})
newdata


# In[81]:


model3.predict(newdata)


# ### Model Deletion Techniques

# In[82]:


#detecting outlires/influencers
#Cook's distance


# In[84]:


model_influence = model.get_influence()
(c, _) = model_influence.cooks_distance


# In[85]:


(np.argmax(c),np.max(c))


# In[86]:


from statsmodels.graphics.regressionplots import influence_plot
influence_plot(model)
plt.show()


# In[88]:


k = time_data.shape[1]
n = time_data.shape[0]
leverage_cutoff = 3*((k +1)/n)
leverage_cutoff


# In[89]:


time_data[time_data.index.isin([7,18])]


# In[90]:


#The diiference in HP and other variable values
time_data.head()


# ### Improving the model

# In[91]:


#Load dataset
time_new = pd.read_csv("delivery_time.csv")


# In[92]:


#Remove the data points which are influencers reset index
time1 = time_new.drop(time_new.index[[7,18]],axis=0).reset_index()


# In[93]:


#Drop original index
time1 = time1.drop(['index'],axis=1)


# In[94]:


time1


# In[96]:


time1=time1.rename({'Delivery Time':'delivery_time','Sorting Time':'sorting_time'},axis=1)


# In[97]:


sns.regplot(x= time1['sorting_time'], y= time1['delivery_time'],data = time1)


# In[98]:


model4 = smf.ols("delivery_time~sorting_time", data = time1).fit()


# In[99]:


newdata2 = pd.DataFrame({'sorting_time': [9,7,5,6,10]})


# In[100]:


newdata2


# In[102]:


model4.predict(newdata2)


# In[101]:


model4.predict(time1)


# In[ ]:




