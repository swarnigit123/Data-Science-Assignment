#!/usr/bin/env python
# coding: utf-8

# ## Forecasting airlinespassengers data

# In[1]:


#import libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import mean_squared_error
from pandas.plotting import lag_plot
from statsmodels.graphics.tsaplots import plot_acf
from statsmodels.tsa.seasonal import seasonal_decompose
from statsmodels.tsa.holtwinters import SimpleExpSmoothing
from statsmodels.tsa.holtwinters import Holt
from statsmodels.tsa.holtwinters import ExponentialSmoothing


# In[2]:


#Loading dataset
airlines = pd.read_excel('Airlines+Data.xlsx')


# In[3]:


airlines


# ### EDA

# In[4]:


airlines.shape


# In[5]:


airlines.info()


# In[6]:


airlines.describe()


# In[7]:


#making the month column as index
airlines.set_index('Month', inplace=True)


# In[8]:


airlines


# In[9]:


airlines.index.year


# In[10]:


airlines.isnull().sum()


# In[11]:


airlines.plot()
plt.show()


# - Here we can say that the trend is upward and the sessionality is multiplicative

# In[12]:


#Histogram and Density plots
airlines.hist()
plt.show()


# In[13]:


#create a density plot
airlines.plot(kind='kde')
plt.show()


# In[14]:


#Lag_plot
lag_plot(airlines)
plt.show()


# In[15]:


#autocorrelation plot
plot_acf(airlines, lags=30)
plt.show()


# In[16]:


unsampled = airlines.resample('M').mean()
print(unsampled.head(32))


# In[18]:


## interplation was done for nan values which we get after doing upsampling by month
interpolated = unsampled.interpolate(method='linear')
print(interpolated.head(15))
interpolated.plot()
plt.show()


# In[19]:


interpolated


# ### Transformation

# In[20]:


#line plot
plt.subplot(211)
plt.plot(airlines)


# In[21]:


#histogram
plt.subplot(212)
plt.hist(airlines)
plt.show


# In[25]:


#square root Transform
dataframe = pd.DataFrame(airlines.values)
dataframe.columns = ['Passengers']
dataframe['Passengers'] = np.sqrt(dataframe['Passengers'])


# In[26]:


#line plot
plt.subplot(211)
plt.plot(airlines['Passengers'])
#histogram
plt.subplot(212)
plt.hist(airlines['Passengers'])
plt.show


# In[28]:


#Log Transform
dataframe = pd.DataFrame(airlines.values)
dataframe.columns = ['Passengers']
dataframe['Passengers'] = np.log(dataframe['Passengers'])

# line plot
plt.subplot(211)
plt.plot(dataframe['Passengers'])
# histogram
plt.subplot(212)
plt.hist(dataframe['Passengers'])
plt.show()


# In[29]:


Train = interpolated.head(81)
Test = interpolated.tail(15)


# In[30]:


#moving average


# In[31]:


plt.figure(figsize=(12,4))
interpolated.Passengers.plot(label="org")
for i in range(2, 24, 6):
    interpolated["Passengers"].rolling(i).mean().plot(label=str(i))
plt.legend(loc='best')


# In[32]:


#Time series decomposition plot


# In[33]:


decompose_ts_add = seasonal_decompose(interpolated.Passengers,freq=12)
decompose_ts_add.plot()
plt.show()


# In[34]:


#ACF plots and PACF plots


# In[35]:


import statsmodels.graphics.tsaplots as tsa_plots


# In[37]:


tsa_plots.plot_acf(interpolated.Passengers, lags=14)
tsa_plots.plot_pacf(interpolated.Passengers, lags=14)
plt.show()


# ### Evaluation metic MAPE

# In[38]:


def MAPE(pred, org):
    temp = np.abs((pred-org)/org)*100
    return np.mean(temp)


# ### Simple Exponential Method

# In[41]:


ses_model = SimpleExpSmoothing(Train["Passengers"]).fit(smoothing_level=0.2)
pred_ses = ses_model.predict(start = Test.index[0],end = Test.index[-1])
MAPE(pred_ses, Test.Passengers)


# ### Holt Method

# In[42]:


hw_model = Holt(Train["Passengers"]).fit(smoothing_level=0.1, smoothing_slope=0.2)
pred_hw = hw_model.predict(start = Test.index[0],end = Test.index[-1])
MAPE(pred_hw, Test.Passengers)


# ### Holts winter exponential smoothing with additive seasonality and additive trend

# In[43]:


hwe_model_add_add = ExponentialSmoothing(Train["Passengers"],seasonal="add",trend="add",seasonal_periods=12).fit(smoothing_level=0.1, smoothing_slope=0.2) #add the trend to the model
pred_hwe_add_add = hwe_model_add_add.predict(start = Test.index[0],end = Test.index[-1])
MAPE(pred_hwe_add_add,Test.Passengers)


# ### Holts winter exponential smoothing with multiplicative seasonality and additive trend 

# In[44]:


hwe_model_mul_add = ExponentialSmoothing(Train["Passengers"],seasonal="mul",trend="add",seasonal_periods=12).fit(smoothing_level=0.1, smoothing_slope=0.2) 
pred_hwe_mul_add = hwe_model_mul_add.predict(start = Test.index[0],end = Test.index[-1])
MAPE(pred_hwe_mul_add,Test.Passengers)


# In[46]:


rmse_hwe_mul_add = np.sqrt(mean_squared_error(pred_hwe_mul_add,Test.Passengers))
rmse_hwe_mul_add


# ### Final model by combining train and test

# In[47]:


hwe_model_add_add = ExponentialSmoothing(interpolated["Passengers"],seasonal="add",trend="add",seasonal_periods=10).fit()


# In[48]:


#Forecasting for next 10 time periods
hwe_model_add_add.forecast(10)


# In[49]:


interpolated


# In[50]:


interpolated.reset_index(inplace=True)


# In[51]:


interpolated['t'] = 1


# In[52]:


interpolated


# In[53]:


for i,row in interpolated.iterrows():
  interpolated['t'].iloc[i] = i+1


# In[54]:


interpolated


# In[56]:


#inserted t_sq column with values
interpolated['t_sq'] = (interpolated['t'])**2


# In[57]:


interpolated


# In[58]:


interpolated["month"] = interpolated.Month.dt.strftime("%b") # month extraction
interpolated["year"] = interpolated.Month.dt.strftime("%Y") # month extraction


# In[59]:


interpolated


# In[60]:


months = pd.get_dummies(interpolated['month']) # converting the dummy variables for month column


# In[61]:


months


# In[62]:


#storing the months as serial wise again in months variable
months = months[['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']]


# In[63]:


Airlines = pd.concat([interpolated,months],axis=1)


# In[64]:


Airlines.head()


# In[65]:


Airlines['log_passengers'] = np.log(Airlines['Passengers'])
Airlines


# In[66]:


plt.figure(figsize=(12,8))
heatmap_y_month = pd.pivot_table(data=Airlines,values="Passengers",index="year",columns="month",aggfunc="mean",fill_value=0)
sns.heatmap(heatmap_y_month,annot=True,fmt="g")


# In[67]:


# Boxplot 
plt.figure(figsize=(8,6))
plt.subplot(211)
sns.boxplot(x="month",y="Passengers",data= Airlines)
plt.subplot(212)
sns.boxplot(x="year",y="Passengers",data=Airlines)


# In[69]:


plt.figure(figsize=(12,3))
sns.lineplot(x="year",y="Passengers",data=Airlines)


# In[70]:


#splitting data


# In[71]:


Train = Airlines.head(81)
Test = Airlines.tail(15)


# In[72]:


#Linear Model
import statsmodels.formula.api as smf 

linear_model = smf.ols('Passengers~t',data=Train).fit()
pred_linear =  pd.Series(linear_model.predict(pd.DataFrame(Test['t'])))
rmse_linear = np.sqrt(np.mean((np.array(Test['Passengers'])-np.array(pred_linear))**2))
rmse_linear


# In[73]:


#Exponential model
Exp = smf.ols('log_passengers~t',data=Train).fit()
pred_Exp = pd.Series(Exp.predict(pd.DataFrame(Test['t'])))
rmse_Exp = np.sqrt(np.mean((np.array(Test['Passengers'])-np.array(np.exp(pred_Exp)))**2))
rmse_Exp


# In[74]:


#Quadratic model
Quad = smf.ols('Passengers~t+t_sq',data=Train).fit()
pred_Quad = pd.Series(Quad.predict(Test[["t","t_sq"]]))
rmse_Quad = np.sqrt(np.mean((np.array(Test['Passengers'])-np.array(pred_Quad))**2))
rmse_Quad


# In[75]:


#Additive seasonality 
add_sea = smf.ols('Passengers~Jan+Feb+Mar+Apr+May+Jun+Jul+Aug+Sep+Oct+Nov',data=Train).fit()
pred_add_sea = pd.Series(add_sea.predict(Test[['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov']]))
rmse_add_sea = np.sqrt(np.mean((np.array(Test['Passengers'])-np.array(pred_add_sea))**2))
rmse_add_sea


# In[76]:


#Additive Seasonality Quadratic 
add_sea_Quad = smf.ols('Passengers~t+t_sq+Jan+Feb+Mar+Apr+May+Jun+Jul+Aug+Sep+Oct+Nov',data=Train).fit()
pred_add_sea_quad = pd.Series(add_sea_Quad.predict(Test[['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','t','t_sq']]))
rmse_add_sea_quad = np.sqrt(np.mean((np.array(Test['Passengers'])-np.array(pred_add_sea_quad))**2))
rmse_add_sea_quad


# In[77]:


#Multiplicative Seasonality
Mul_sea = smf.ols('log_passengers~Jan+Feb+Mar+Apr+May+Jun+Jul+Aug+Sep+Oct+Nov',data = Train).fit()
pred_Mult_sea = pd.Series(Mul_sea.predict(Test))
rmse_Mult_sea = np.sqrt(np.mean((np.array(Test['Passengers'])-np.array(np.exp(pred_Mult_sea)))**2))
rmse_Mult_sea


# In[78]:


#Multiplicative Additive Seasonality 
Mul_Add_sea = smf.ols('log_passengers~t+Jan+Feb+Mar+Apr+May+Jun+Jul+Aug+Sep+Oct+Nov',data = Train).fit()
pred_Mult_add_sea = pd.Series(Mul_Add_sea.predict(Test))
rmse_Mult_add_sea = np.sqrt(np.mean((np.array(Test['Passengers'])-np.array(np.exp(pred_Mult_add_sea)))**2))
rmse_Mult_add_sea


# In[79]:


#Compareing the results 
data = {"MODEL":pd.Series(["rmse_linear","rmse_Exp","rmse_Quad","rmse_add_sea","rmse_add_sea_quad","rmse_Mult_sea","rmse_Mult_add_sea"]),"RMSE_Values":pd.Series([rmse_linear,rmse_Exp,rmse_Quad,rmse_add_sea,rmse_add_sea_quad,rmse_Mult_sea,rmse_Mult_add_sea])}
table_rmse=pd.DataFrame(data)
table_rmse.sort_values(['RMSE_Values'])


# - rmse_Multi_add_sea model have lowest rmse value
# - so we can use this model for predictions

# In[81]:


newdata = [['2003-01-01', 'Jan'], ['2003-02-01', 'Feb'], ['2003-03-01', 'Mar'],['2003-04-01', 'Apr'],['2003-5-01', 'May'],['2003-06-01', 'Jun'],
        ['2003-07-01', 'Jul'],['2003-08-01', 'Aug'],['2003-09-01', 'Sep'],['2003-10-01', 'Oct'],['2003-11-01', 'Nov'],['2003-12-01', 'Dec'],
          ['2004-01-01', 'Jan'],['2004-02-01', 'Feb'],['2004-03-01', 'Mar'],['2004-04-01', 'Apr'],['2004-05-01', 'May'],['2004-06-01', 'Jun'],
          ['2004-07-01', 'Jul'],['2004-08-01', 'Aug'],['2004-09-01', 'Sep'],['2004-10-01', 'Oct'],['2004-11-01', 'Nov'],['2004-12-01', 'Dec']]
forecast = pd.DataFrame(newdata, columns = ['Date', 'Months'])
forecast


# In[83]:


# Create dummies & T and T-Squared columns
dummies = pd.DataFrame(pd.get_dummies(forecast['Months']))
forecast1 = pd.concat([forecast,dummies],axis = 1)

forecast1["t"] = np.arange(1,25)   
forecast1["t_squared"] = forecast1["t"]*forecast1["t"] 
print("\nDummy, T and T-Square\n\n",forecast1.head())


# In[87]:


# Forecasting using Multiplicative Additive Seasonality Model Because RMSE Value is Less Compared to  Other RMSE Values

final_model = smf.ols('log_passengers~t+Jan+Feb+Mar+Apr+May+Jun+Jul+Aug+Sep+Oct+Nov',data = Train).fit()
pred_new  = pd.Series(final_model.predict(forecast1))

forecast1["Forecasted_log"] = pd.Series(pred_new)

forecast1['Forecasted_Passengers'] = np.exp(forecast1['Forecasted_log'])


# In[88]:


# Final Prediction for next 12 months

Final_predict = forecast1.loc[:, ['Date', 'Forecasted_Passengers']] 
Final_predict


# In[ ]:




