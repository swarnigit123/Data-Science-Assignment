#!/usr/bin/env python
# coding: utf-8

# ## Forecasting on cococola_Sales_data

# In[1]:


#import libraries
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import statsmodels.formula.api as smf


# In[2]:


#import datasets
cococola= pd.read_excel('CocaCola_Sales_Rawdata.xlsx')
cococola


# ### EDA

# In[3]:


cococola.shape


# In[4]:


cococola.describe()


# In[5]:


cococola.info()


# In[6]:


quarter = ['Q1', 'Q2', 'Q3', 'Q4']
n = cococola['Quarter'][0]
n[0:2]


# In[7]:


cococola['quarter']=0


# In[8]:


cococola['Year']=0


# In[9]:


for i in range(42):
    n=cococola['Quarter'][i]
    cococola['quarter'][i]=n[0:2]
    cococola['Year'][i] = n[3:5]


# In[10]:


dummy = pd.DataFrame(pd.get_dummies(cococola['quarter']))


# In[11]:


cococola= pd.concat([cococola,dummy],axis = 1)
cococola.head()


# In[12]:


# Lineplot for Sales of CocaCola
plt.figure(figsize=(10,7))
plt.plot(cococola['Sales'], color = 'blue', linewidth=1)


# In[13]:


# Histogram
cococola['Sales'].hist(figsize=(8,5))


# In[14]:


# Density Plot
cococola['Sales'].plot(kind = 'kde', figsize=(8,5))


# In[15]:


#boxplot of Quarters Vs. Sales
sns.set(rc={'figure.figsize':(8,5)})
sns.boxplot(x="quarter",y="Sales",data=cococola)


# In[16]:


# boxplot of Years Vs. Sales
sns.boxplot(x="Year",y="Sales",data=cococola)


# In[17]:


from pandas.plotting import lag_plot
lag_plot(cococola['Sales'])
plt.show()


# In[18]:


plt.figure(figsize=(8,5))
sns.lineplot(x="Year",y="Sales",data=cococola)


# In[19]:


import statsmodels.graphics.tsaplots as tsa_plots
tsa_plots.plot_acf(cococola.Sales,lags=12)
tsa_plots.plot_pacf(cococola.Sales,lags=12)
plt.show()


# In[20]:


plt.figure(figsize=(12,4))
cococola.Sales.plot(label="org")
for i in range(2,8,2):
    cococola["Sales"].rolling(i).mean().plot(label=str(i))
plt.legend(loc='best')


# In[21]:


# Time Series Decomposition Plot

from statsmodels.tsa.seasonal import seasonal_decompose

decompose_ts_add = seasonal_decompose(cococola.Sales,period=12)
decompose_ts_add.plot()
plt.show()


# In[22]:


t= np.arange(1,43)
cococola['t']=t
cococola['t_square']=cococola['t']*cococola['t']


# In[23]:


log_Sales  =np.log(cococola['Sales'])
cococola['log_Sales']=log_Sales


# In[24]:


train = cococola.head(32)
test = cococola.tail(8)


# ### Models

# In[25]:


import statsmodels.formula.api as smf


# In[26]:


#linear model
linear= smf.ols('Sales~t',data=train).fit()
predlin=pd.Series(linear.predict(pd.DataFrame(test['t'])))
rmselin=np.sqrt((np.mean(np.array(test['Sales'])-np.array(predlin))**2))
rmselin


# In[27]:


#quadratic model
quad=smf.ols('Sales~t+t_square',data=train).fit()
predquad=pd.Series(quad.predict(pd.DataFrame(test[['t','t_square']])))
rmsequad=np.sqrt(np.mean((np.array(test['Sales'])-np.array(predquad))**2))
rmsequad


# In[28]:


#exponential model
expo=smf.ols('log_Sales~t',data=train).fit()
predexp=pd.Series(expo.predict(pd.DataFrame(test['t'])))
predexp
rmseexpo=np.sqrt(np.mean((np.array(test['Sales'])-np.array(np.exp(predexp)))**2))
rmseexpo


# In[29]:


#additive seasonality
additive= smf.ols('Sales~ Q1+Q2+Q3+Q4',data=train).fit()
predadd=pd.Series(additive.predict(pd.DataFrame(test[['Q1','Q2','Q3','Q4']])))
predadd
rmseadd=np.sqrt(np.mean((np.array(test['Sales'])-np.array(predadd))**2))
rmseadd


# In[30]:


#additive seasonality with linear trend
addlinear= smf.ols('Sales~t+Q1+Q2+Q3+Q4',data=train).fit()
predaddlinear=pd.Series(addlinear.predict(pd.DataFrame(test[['t','Q1','Q2','Q3','Q4']])))
predaddlinear


# In[31]:


rmseaddlinear=np.sqrt(np.mean((np.array(test['Sales'])-np.array(predaddlinear))**2))
rmseaddlinear


# In[32]:


#additive seasonality with quadratic trend
addquad=smf.ols('Sales~t+t_square+Q1+Q2+Q3+Q4',data=train).fit()
predaddquad=pd.Series(addquad.predict(pd.DataFrame(test[['t','t_square','Q1','Q2','Q3','Q4']])))
rmseaddquad=np.sqrt(np.mean((np.array(test['Sales'])-np.array(predaddquad))**2))
rmseaddquad


# In[33]:


#multiplicative seasonality
mulsea=smf.ols('log_Sales~Q1+Q2+Q3+Q4',data=train).fit()
predmul= pd.Series(mulsea.predict(pd.DataFrame(test[['Q1','Q2','Q3','Q4']])))
rmsemul= np.sqrt(np.mean((np.array(test['Sales'])-np.array(np.exp(predmul)))**2))
rmsemul


# In[34]:


#multiplicative seasonality with linear trend
mullin= smf.ols('log_Sales~t+Q1+Q2+Q3+Q4',data=train).fit()
predmullin= pd.Series(mullin.predict(pd.DataFrame(test[['t','Q1','Q2','Q3','Q4']])))
rmsemulin=np.sqrt(np.mean((np.array(test['Sales'])-np.array(np.exp(predmullin)))**2))
rmsemulin


# In[35]:


#multiplicative seasonality with quadratic trend
mul_quad= smf.ols('log_Sales~t+t_square+Q1+Q2+Q3+Q4',data=train).fit()
pred_mul_quad= pd.Series(mul_quad.predict(test[['t','t_square','Q1','Q2','Q3','Q4']]))
rmse_mul_quad=np.sqrt(np.mean((np.array(test['Sales'])-np.array(np.exp(pred_mul_quad)))**2))
rmse_mul_quad


# In[36]:


#tabulating the rmse values
data={'Model':pd.Series(['rmse_mul_quad','rmseadd','rmseaddlinear','rmseaddquad','rmseexpo','rmselin','rmsemul','rmsemulin','rmsequad']),'Values':pd.Series([rmse_mul_quad,rmseadd,rmseaddlinear,rmseaddquad,rmseexpo,rmselin,rmsemul,rmsemulin,rmsequad])}


# In[37]:


data =pd.DataFrame(data)
data


# - From the above table Quadratic Additive Seasonality model has less RMSE value
# - So we can consider this value for model building

# In[38]:


#final model with least rmse value
cococola.head()


# In[39]:


final_model = smf.ols('Sales~t+t_square+Q1+Q2+Q3+Q4',data=train).fit()
pred_final = pd.Series(final_model.predict(cococola[['t','t_square','Q1','Q2','Q3','Q4']]))
rmse_final_model =np.sqrt(np.mean((np.array(cococola['Sales'])-np.array(pred_final))**2))
rmse_final_model


# In[40]:


#Predict values
pred_df = pd.DataFrame({'Actual': cococola.Sales, 'Predicted': pred_final})
pred_df


# In[ ]:




