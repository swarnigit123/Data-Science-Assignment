#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np


# In[2]:


book = pd.read_csv('book.csv', encoding= 'unicode_escape')


# In[3]:


book


# In[4]:


book.drop(['Unnamed: 0'],axis=1)


# In[5]:


book.rename(columns = {'User.ID': 'User_ID','Book.Title':'Book_title','Book.Rating':'Book_rating'}, inplace=True)


# In[6]:


#Finding unique users in dataset
len(book.User_ID.unique())


# In[7]:


len(book.Book_title.unique())


# In[8]:


user_book = book.pivot_table(index= 'User_ID',
                            columns='Book_title',
                            values ='Book_rating').reset_index(drop=True)


# In[9]:


user_book


# In[10]:


user_book.index = book.User_ID.unique()


# In[11]:


user_book


# In[12]:


#Imputing NaNs with 0
user_book.fillna(0, inplace=True)
user_book


# ### Cosine similarities between users

# In[13]:


from sklearn.metrics import pairwise_distances
from scipy.spatial.distance import cosine, correlation


# In[14]:


user_sim = 1 - pairwise_distances(user_book.values, metric='cosine')
user_sim


# In[15]:


user_sim_df = pd.DataFrame(user_sim)


# In[16]:


#Set the index and column name to user ids
user_sim_df.index = book.User_ID.unique()
user_sim_df.columns = book.User_ID.unique()


# In[17]:


user_sim_df.iloc[0:10, 0:10]


# In[18]:


np.fill_diagonal(user_sim,0)
user_sim_df.iloc[0:10,0:10]


# In[19]:


#Most similar users
user_sim_df.idxmax(axis=1)[0:10]


# In[20]:


book[(book['User_ID']==276729) | (book['User_ID']==276726)]


# In[21]:


user1 = book[book['User_ID']==276726]


# In[22]:


user2 = book[book['User_ID']==276737]


# In[23]:


user2.Book_title


# In[24]:


user1.Book_title


# In[25]:


pd.merge(user1,user2,on='Book_title', how='outer')


# In[ ]:




