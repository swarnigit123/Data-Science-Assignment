#!/usr/bin/env python
# coding: utf-8

# ## Logistic Regression and Deployment

# In[1]:


#Import Libraries
import pandas as pd
import numpy as np
from sklearn.linear_model import LogisticRegression


# In[2]:


#Load data
bank= pd.read_csv('bank-full.csv', encoding='utf-8', delimiter=";")
bank


# ### EDA

# In[3]:


bank.shape


# In[4]:


bank.head()


# In[5]:


bank.info()


# In[6]:


bank.columns


# In[7]:


from sklearn import preprocessing
from sklearn.preprocessing import LabelEncoder, OneHotEncoder


# In[8]:


#Label_encoder object
label_encoder = LabelEncoder()


# In[9]:


#Encoding labels in column
bank['job']= label_encoder.fit_transform(bank['job'])
bank['marital']= label_encoder.fit_transform(bank['marital'])
bank['education']= label_encoder.fit_transform(bank['education'])
bank['default']= label_encoder.fit_transform(bank['default'])
bank['housing']= label_encoder.fit_transform(bank['housing'])
bank['loan']= label_encoder.fit_transform(bank['loan'])
bank['contact']= label_encoder.fit_transform(bank['contact'])
bank['month']= label_encoder.fit_transform(bank['month'])
bank['poutcome']= label_encoder.fit_transform(bank['poutcome'])
bank['y']= label_encoder.fit_transform(bank['y'])
bank.head(10)


# In[10]:


#REmoving NA values

bank = bank.dropna()


# In[11]:


bank.shape


# ### Model Building

# In[12]:


#Split data into train and test data
X = bank.iloc[:,1:]
Y = bank.iloc[:,16]


# In[13]:


#Logistic Regression model
bank = LogisticRegression()
bank.fit(X,Y)


# ### Model Predictions

# In[14]:


#predict for X test dataset
y_pred = bank.predict(X)


# In[15]:


y_pred_df = pd.DataFrame({'actual': Y,
                         'predicted_prob': bank.predict(X)})


# In[16]:


y_pred_df


# ### Model Testing

# In[17]:


#Create confusion matrix for the model accuracy


# In[18]:


from sklearn.metrics import confusion_matrix
confusion_matrix = confusion_matrix(Y, y_pred)


# In[19]:


confusion_matrix


# In[20]:


((39129+2011)/(39129+793+2011+3278))*100


# In[21]:


#Classification report
from sklearn.metrics import classification_report
print(classification_report(Y, y_pred))


# In[22]:


#ROC Curve plotting and finding aic value


# In[23]:


from sklearn.metrics import roc_curve
from sklearn.metrics import roc_auc_score
fpr, tpr, thresholds = roc_curve(Y, bank.predict_proba (X)[:,1])
auc = roc_auc_score(Y, y_pred)


# In[24]:


import matplotlib.pyplot as plt
plt.plot(fpr, tpr, color = 'red', label='logit model (area = %0.2f)'%auc)
plt.plot([0,1], [0,1], 'k--')
plt.xlabel('False Positive Rate or [1 - True Negative Rate]')
plt.ylabel('True Positive Rate')


# In[25]:


auc


# In[ ]:




