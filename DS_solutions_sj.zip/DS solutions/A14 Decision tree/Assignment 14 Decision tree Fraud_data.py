#!/usr/bin/env python
# coding: utf-8

# In[3]:


#import libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


# In[4]:


#load dataset
Fraud_data = pd.read_csv('Fraud_check (1).csv')
Fraud_data.head(10)


# In[5]:


Fraud_data.isnull().any()


# In[7]:


Fraud_data.dtypes


# In[8]:


Fraud_data.describe()


# In[9]:


Fraud_data.info()


# In[10]:


Fraud_data['Undergrad'],class_names = pd.factorize(Fraud_data['Undergrad'])
Fraud_data.Undergrad
print(class_names)


# In[11]:


Fraud_data['Marital.Status'],class_names2 = pd.factorize(Fraud_data['Marital.Status'])
Fraud_data['Marital.Status']
print(class_names2)


# In[12]:


Fraud_data['Urban'],class_names3 = pd.factorize(Fraud_data['Urban'])
Fraud_data['Urban']
print(class_names3)


# In[13]:


Fraud_data.info()


# In[14]:


Fraud_data['Taxable.Income'].plot.hist()
plt.show()


# In[15]:


Fraud_data['Taxable.Income'].describe()


# In[16]:


#Converting the sales column which is continous into categorical
category = pd.cut(Fraud_data['Taxable.Income'],bins=[0,30000,99619],labels = ['Risky', 'Good'])
Fraud_data.insert(0, 'Taxable_Group',category)


# In[17]:


Fraud_data


# In[18]:


import seaborn as sns
sns.pairplot(Fraud_data)


# In[19]:


Fraud_data['Taxable_Group'].unique()
Fraud_data.Taxable_Group.value_counts()


# In[20]:


#Feature selection


# In[21]:


colnames = list(Fraud_data.columns)
colnames


# In[22]:


predictors = colnames[1: ]  #excluding 1st column
predictors


# In[23]:


target = colnames[0] #only 1st column
target


# In[24]:


#splitting data into training and testing data


# In[25]:


from sklearn.model_selection import train_test_split
train,test = train_test_split(Fraud_data,test_size = 0.3)
test


# In[27]:


test.shape


# In[28]:


train


# In[29]:


train.shape


# ### Decision Tree Model Building

# In[30]:


#using entropy cruterion


# In[31]:


from sklearn.tree import DecisionTreeClassifier


# In[32]:


model = DecisionTreeClassifier(criterion = 'entropy')
model.fit(train[predictors], train[target])


# In[33]:


preds = model.predict(test[predictors])
preds


# In[34]:


#plot Decision tree
from sklearn import tree
tree.plot_tree(model);


# In[35]:


fn = ['Undergrad','Marital.Status','Taxable.Income','City.Population','Work.Experience','Urban']
cn = ['Good','Risky']
fig,axes = plt.subplots(nrows = 1, ncols=1, dpi=600)
tree.plot_tree(model,
              feature_names = fn,
              class_names = cn,
              filled = True);


# In[36]:


from sklearn import metrics
print('Accuracy:', metrics.accuracy_score(test[target],preds))


# In[37]:


pd.Series(preds).value_counts()


# In[38]:


pd.crosstab(test[target],preds)


# In[39]:


np.mean(preds==test.Taxable_Group)


# In[40]:


model.score(test[predictors],test[target])


# In[ ]:




