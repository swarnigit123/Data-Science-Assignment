#!/usr/bin/env python
# coding: utf-8

# ## Decision Tree on company_data

# In[1]:


#Import libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
get_ipython().run_line_magic('matplotlib', 'inline')
from sklearn import preprocessing
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.tree import plot_tree


# In[2]:


#Load the dataset
df = pd.read_csv('Company_Data (1).csv')
df.head()


# ### EDA and Data Visualization

# In[3]:


df.info()


# In[4]:


df.describe()


# In[5]:


df.shape


# In[6]:


df.isnull().sum()


# In[7]:


#convert sales column into categorical column
df['Sales'] = pd.cut(x=df['Sales'],bins=[0,6,12,17], labels=['Low', 'Medium', 'High'], right=False)
df['Sales']


# In[8]:


#paiplot for visualize attributes all at once
sns.pairplot(data=df, hue= 'Sales')


# In[9]:


df['Sales'].value_counts()


# In[10]:


#convert categorical value into numeric column
label_encoder = preprocessing.LabelEncoder()

df['Sales'] = label_encoder.fit_transform(df['Sales'])
df['ShelveLoc'] = label_encoder.fit_transform(df['ShelveLoc'])
df['Urban'] = label_encoder.fit_transform(df['Urban'])
df['US'] = label_encoder.fit_transform(df['US'])


# In[11]:


df


# In[12]:


#split the data into train data and test data
X = df.drop('Sales', axis = 1)
y = df['Sales']


# In[13]:


X


# In[14]:


y


# In[15]:


# Splitting data into training and testing data
x_train, x_test, y_train, y_test = train_test_split(X, y, test_size= 0.33, random_state= 40)


# ### Building Decision Tree Classifier using Entropy criteria

# In[16]:


model = DecisionTreeClassifier(criterion = 'entropy', max_depth=4)
model.fit(x_train, y_train)


# In[17]:


from sklearn import tree
#plot Decision tree
tree.plot_tree(model);


# In[18]:


fn = ['CompPrice', 'Income', 'Advertising', 'Population', 'Price', 'ShelveLoc', 'Age', 'Education'
        'Urban', 'US',]
cn = ['Low', 'Medium', 'High']
fig,axes = plt.subplots(nrows = 1, ncols=1, figsize= (8,8), dpi=600)
tree.plot_tree(model,
              feature_names = fn,
              class_names = cn,
              filled = True);


# In[19]:


#predicting on test data
preds = model.predict(x_test)
pd.Series(preds).value_counts()


# In[20]:


preds


# In[21]:


#getting the 2 way table to understand the correct and wrong predictions
pd.crosstab(y_test,preds)


# In[22]:


#Accuracy
np.mean(preds==y_test)


# ### Building Decision Tree Classifier (CART) using Gini Criteria

# In[23]:


from sklearn.tree import DecisionTreeClassifier
model_gini = DecisionTreeClassifier(criterion='gini', max_depth=3)


# In[24]:


model_gini.fit(x_train, y_train)


# In[25]:


#Plotting decision tree
tree.plot_tree(model_gini);


# In[26]:


fn = ['CompPrice', 'Income', 'Advertising', 'Population', 'Price', 'ShelveLoc', 'Age', 'Education'
        'Urban', 'US',]
cn = ['Low', 'Medium', 'High']
fig,axes = plt.subplots(nrows = 1, ncols=1, figsize= (6,6), dpi=600)
tree.plot_tree(model_gini,
              feature_names = fn,
              class_names = cn,
              filled = True);


# In[27]:


#Predicting on test data
pred = model_gini.predict(x_test)
pd.Series(pred).value_counts()


# In[28]:


pred


# In[29]:


#Creating cross table for checking the model
pd.crosstab(y_test, pred)


# In[30]:


#Accuracy
np.mean(pred==y_test)


# In[ ]:




